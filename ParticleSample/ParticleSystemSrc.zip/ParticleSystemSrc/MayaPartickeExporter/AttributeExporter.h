#pragma once

#include <maya/MObject.h>
#include <maya/MPlug.h>

namespace ParticleSample
{
	class ExpDataHandler;

	// General MObject attribute exporter.
	// It's designed to export any kind of data, 
	// and pass it to ExpDataHandler.
	class AttributeExporter
	{
	public:
		AttributeExporter();

		// Starts new group on the current m_dataHandler
		void StartNewGroup(const char *groupName);
		
		// Closes current group
		void CloseGroup();
		
		// Exports attribute data with specified name
		MStatus Export(const char *attributeName);
		
		// Exports attribute data from specified attribute
		MStatus Export(MObject attribute);
		
		// Sets object from which attribute data will be exported
		void SetObject(const MObject &mObject);
		
		// Sets current data handler
		void SetDataHandler(ExpDataHandler *dataHandler);
		
		// Returns current data handler
		ExpDataHandler* GetExpDataHandler();
	
	private:
		// Exporter for each type of data
		MStatus GetEnumAttributeValue(MObject attribute, MPlug plug);
		MStatus GetNumericAttributeValue(MObject attribute, MPlug plug);
		MStatus GetUnitAttribute(MObject attribute, MPlug plug);

		MObject m_mObject;
		ExpDataHandler *m_dataHandler;
	};

	inline void AttributeExporter::SetObject(const MObject &mObject)
	{
		m_mObject = mObject;
	}

	inline void AttributeExporter::SetDataHandler(ExpDataHandler *dataHandler)
	{
		m_dataHandler = dataHandler;
	}

	inline ExpDataHandler* AttributeExporter::GetExpDataHandler()
	{
		return m_dataHandler;
	}
}

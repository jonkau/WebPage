#pragma once 

namespace ParticleSample
{
	// Abstract class, which is used to define data exporter interface,
	// in this way we can implement exporting to any media, 
	// which can logicaly handle these methods
	class ExpDataHandler
	{
	public:
		virtual ~ExpDataHandler(){};
		// Exported data must be logicaly grouped,
		// so any exporter must implement following methods

		// Starts new group. 
		// All following export methods should export into this new group.
		// This method can be called multiple times - 
		// in such way you can create groups in other group.
		// But there is only one active group at the time.
		virtual void StartNewGroup(const char *groupName) = 0;
		
		// Closes current active group.
		virtual void CloseGroup() = 0;
		
		// Exporter functions for all kind of data. 
		// Returns true if export was sucesful, false if not
		virtual bool ExportString(const char *value, const char *attributeName) = 0;
		virtual bool ExportDouble(double values, const char *attributeName) = 0;
		virtual bool ExportDouble(double *value, size_t count, const char *attributeName) = 0;
		virtual bool ExportInt(int values, const char *attributeName) = 0;
		virtual bool ExportBool(bool value, const char *attributeName) = 0;
		virtual bool ExportShort(short value, const char *attributeName) = 0;
	};
}


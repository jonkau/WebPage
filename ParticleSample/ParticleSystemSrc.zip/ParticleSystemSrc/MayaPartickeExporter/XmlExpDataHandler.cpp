#include "XmlExpDataHandler.h"
#include "../TinyXML/tinyxml.h"


namespace ParticleSample
{
	void XmlExpDataHandler::StartNewGroup(const char *groupName)
	{
		m_currentXmlElement = m_currentXmlElement->InsertEndChild(TiXmlElement(groupName))->ToElement();
	}

	void XmlExpDataHandler::CloseGroup()
	{
		m_currentXmlElement = m_currentXmlElement->Parent()->ToElement();
	}

	bool XmlExpDataHandler::ExportString(const  char *value, const char *attributeName)
	{
		m_currentXmlElement->SetAttribute(attributeName, value);
		return true;
	}

	bool XmlExpDataHandler::ExportDouble(double value, const char *attributeName)
	{						
		char buffer[256];
		if(-1 != sprintf_s(buffer, "%f", value))
		{
			m_currentXmlElement->SetAttribute(attributeName, buffer);
			return true;
		}
		else
		{
			return false;
		}
	}

	bool XmlExpDataHandler::ExportDouble(double *values, size_t count, const char *attributeName)
	{
		if(count > 1)
		{
			const static size_t bufferSize = 256;
			char buffer[bufferSize ];
			if(-1 == sprintf_s(buffer, bufferSize , "%f", values[0]))
			{
				return false;
			}	

			for(size_t i = 1; i < count; ++i)
			{
				size_t currentSize = strlen(buffer);
				if(-1 == sprintf_s(&buffer[currentSize], bufferSize - currentSize, ";%f", values[i]))
				{
					return false;
				}			
			}

			m_currentXmlElement->SetAttribute(attributeName, buffer);
		}
		return true;
	}

	bool XmlExpDataHandler::ExportInt(int value, const char *attributeName)
	{
		m_currentXmlElement->SetAttribute(attributeName, value);
		return true;
	}

	bool XmlExpDataHandler::ExportBool(bool value, const char *attributeName)
	{
		m_currentXmlElement->SetAttribute(attributeName, value?"true":"false");
		return true;
	}

	bool XmlExpDataHandler::ExportShort(short value, const char *attributeName)
	{
		char buffer[256];
		if(-1 != sprintf_s(buffer, "%i", value))
		{
			m_currentXmlElement->SetAttribute(attributeName, buffer);
			return true;
		}
		else
		{
			return false;
		}
	}
}
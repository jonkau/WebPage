#include <stdio.h> 
#include <iomanip>
#include <fstream>

#include <vector>
#include <algorithm>

#include <maya/MString.h> 
#include <maya/MArgList.h> 
#include <maya/MFnPlugin.h> 
#include <maya/MPxCommand.h>
#include <maya/MDagPath.h> 
#include <maya/MSelectionList.h> 
#include <maya/MFnDagNode.h> 
#include <maya/MGlobal.h> 
#include <maya/MPxNode.h> 
#include <maya/MFnAttribute.h> 
#include <maya/MFnNumericAttribute.h> 
#include <maya/MFnUnitAttribute.h> 
#include <maya/MFnEnumAttribute.h>
#include <maya/MFn.h> 
#include <maya/MItDag.h> 
#include <maya/MFnCamera.h> 
#include <maya/MVector.h> 
#include <maya/MFnLight.h>
#include <maya/MColor.h>
#include <maya/MMatrix.h>
#include <maya/MFnNurbsSurface.h>
#include <maya/MPlugArray.h>
#include <maya/MFnParticleSystem.h>

#include <maya/MFnField.h>
#include <maya/MFnGravityField.h>



#include <maya/MItDependencyNodes.h>


#include <maya/MPxFileTranslator.h> 
#include <maya/MIOStream.h> 

#include "AttributeExporter.h"
#include "XmlExpDataHandler.h"

#include "../TinyXML/tinyxml.h"

class ParticleExporter:public MPxFileTranslator  
{ 
public: 
	static const char*      EXPORTER_NAME;
							ParticleExporter(); 
	virtual					~ParticleExporter(); 
	virtual MStatus			writer (const MFileObject& file, const MString& optionsString, 
									MPxFileTranslator::FileAccessMode mode); 
	virtual bool			haveWriteMethod () const; 
	virtual bool			haveReadMethod () const; 
	virtual bool			canBeOpened () const; 
	virtual MString			defaultExtension () const; 
	virtual MString			filter () const;

	static void*   creator(); 

	void ExportParticleInfo();
private:
	void ExtractGeneralFieldData(const MObject &field);
	void ExtractGravityFieldData(const MObject &gravityField);
	void ExtractRadialFieldData(const MObject &radialField);
	void ExtractGeneralEmmiterData(const MObject &emitter, const MObject &particleShape);
	void ExtractParticleSystemData(const MFnParticleSystem &fnParticleSystem);

	ParticleSample::AttributeExporter m_attributeExporter;
	ParticleSample::XmlExpDataHandler m_xmlExpDataHandler;
}; 

const char* ParticleExporter::EXPORTER_NAME = "Particle exporter";

ParticleExporter::ParticleExporter()
{
	m_attributeExporter.SetDataHandler(&m_xmlExpDataHandler);
}

ParticleExporter::~ParticleExporter()
{
}

MStatus	ParticleExporter::writer (const MFileObject& file, const MString& optionsString, 
									MPxFileTranslator::FileAccessMode mode)
{
	TiXmlDocument xmlDocument;
	xmlDocument.FirstChildElement();

	TiXmlElement *rootElement = xmlDocument.InsertEndChild(TiXmlElement("ParticleSystem"))->ToElement();

	if(!rootElement)
	{
		//TODO: report error
		return MStatus::kFailure;
	}
	
	m_xmlExpDataHandler.SetXmlElement(rootElement);

	ExportParticleInfo();

	xmlDocument.SaveFile(file.fullName().asChar());
	
	return MStatus::kSuccess;
}

bool ParticleExporter::haveWriteMethod () const
{
	return true;
}

bool ParticleExporter::haveReadMethod () const
{
	return false;
}

bool ParticleExporter::canBeOpened () const
{
	return false;
}

MString	ParticleExporter::defaultExtension () const
{
	return "xml";
}

MString	ParticleExporter::filter () const
{
	return "*.xml";
}

void*   ParticleExporter::creator()
{
	return new ParticleExporter;
}

void ParticleExporter::ExtractGeneralFieldData(const MObject &field)
{
	 MFnField fnField(field);

	m_attributeExporter.StartNewGroup("Field");

	m_attributeExporter.GetExpDataHandler()->ExportString(fnField.name().asChar(), "name");

	m_attributeExporter.SetObject(fnField.object());
	m_attributeExporter.Export("translate");
	m_attributeExporter.Export("volumeExclusion");
	m_attributeExporter.Export("volumeOffset");
	m_attributeExporter.Export("volumeShape");	
	m_attributeExporter.Export("useMaxDistance");
	m_attributeExporter.Export("maxDistance");
	m_attributeExporter.Export("magnitude");

	m_attributeExporter.CloseGroup();
}


void ParticleExporter::ExtractGravityFieldData(const MObject &gravityField)
{
	MFnGravityField mFnGravityField(gravityField);
	m_attributeExporter.StartNewGroup("Gravity");
	double values[3];
	mFnGravityField.direction().get(values);
	m_attributeExporter.GetExpDataHandler()->ExportDouble(values, 3, "direction");
	m_attributeExporter.Export("direction");
	ExtractGeneralFieldData(gravityField);
	m_attributeExporter.CloseGroup();
}

void ParticleExporter::ExtractRadialFieldData(const MObject &radialField)
{	
	m_attributeExporter.StartNewGroup("Radial");
	ExtractGeneralFieldData(radialField);
	m_attributeExporter.CloseGroup();
}



void ParticleExporter::ExtractGeneralEmmiterData(const MObject &emitter, const MObject &particleShape)
{
	MStatus status = MStatus::kFailure;

	m_attributeExporter.StartNewGroup("Emitter");

	MFnDependencyNode fnDependencyNode;
	
	fnDependencyNode.setObject(emitter);
	m_attributeExporter.GetExpDataHandler()->ExportString(fnDependencyNode.name().asChar(), "name");
	fnDependencyNode.setObject(particleShape);
	m_attributeExporter.GetExpDataHandler()->ExportString(fnDependencyNode.name().asChar(), "particleShape");

	m_attributeExporter.SetObject(emitter);
	m_attributeExporter.Export("translate");
	m_attributeExporter.Export("direction");
	m_attributeExporter.Export("spread");
	m_attributeExporter.Export("speed");
	m_attributeExporter.Export("speedRandom");

	m_attributeExporter.Export("rate");
	m_attributeExporter.Export("scaleRateByObjectSize");	
	m_attributeExporter.Export("maxDistance");
	m_attributeExporter.Export("minDistance");
	m_attributeExporter.Export("spread");

	m_attributeExporter.Export("emitterType");
	
	m_attributeExporter.CloseGroup();
}

void ParticleExporter::ExtractParticleSystemData(const MFnParticleSystem &fnParticleSystem)
{

	m_attributeExporter.GetExpDataHandler()->ExportString(fnParticleSystem.name().asChar(), "name");

	m_attributeExporter.SetObject(fnParticleSystem.object());
	m_attributeExporter.Export("lifespanRandom");
	m_attributeExporter.Export("lifespan");
	m_attributeExporter.Export("maxCount");
	m_attributeExporter.Export("lifespanMode");
}


struct EmitterToParticleShape
{
	MObject emitter;
	MObject particleShape;

	bool operator == (const EmitterToParticleShape &value) const
	{
		return value.emitter == emitter && value.particleShape == particleShape;
	}
};

void ParticleExporter::ExportParticleInfo()
{
	MItDag it(MItDag::kDepthFirst, MFn::kParticle);

	//use vector, coz for estimated size of fields it should be suficient
	typedef std::vector<MObject> MObjects;
	MObjects mFields;

	typedef std::vector<EmitterToParticleShape> EmitterToParticleShapeList;
	EmitterToParticleShapeList emitterToParticleShapeList;

	//create here and use in the loop to extract field and DagNode data
	MFnField fnField;
	MFnDagNode fnDagNode; 

	m_attributeExporter.StartNewGroup("ParticleShapes");
	while(!it.isDone())
	{
		MFnParticleSystem fn(it.item());

		m_attributeExporter.StartNewGroup("ParticleShape");

		ExtractParticleSystemData(fn);

		// get a list of connections to the particle shape.
		// this will be an array of plugs representing the
		// attributes on this kParticle node that are
		// connected to other nodes
		MPlugArray plugs;
		fn.getConnections(plugs);

		// loop through each connection
		for(UINT i=0; i<plugs.length(); ++i)
		{
			// get the connections to this attribute
			MPlugArray attrplugs;
			plugs[i].connectedTo(attrplugs, true, false);

			// loop through each attribute connection
			for(UINT j=0;j<attrplugs.length();++j) 
			{
				MObject obj = attrplugs[j].node();
				switch(obj.apiType()) 
				{
					case MFn::kAir:
					case MFn::kDrag:
					case MFn::kGravity:
					case MFn::kNewton:
					case MFn::kRadial:
					case MFn::kTurbulence:
					case MFn::kUniform:
					case MFn::kVortex:
					case MFn::kVolumeAxis:
						m_attributeExporter.StartNewGroup("Field");
						fnField.setObject(obj);
						m_attributeExporter.GetExpDataHandler()->ExportString(fnField.name().asChar(), "name");
						m_attributeExporter.CloseGroup();
						if(mFields.end() == std::find(mFields.begin(), mFields.end(), obj))
						{
							mFields.push_back(obj);
						};
					break;

					case MFn::kEmitter:
					{
						EmitterToParticleShape emitterToParticleShape;
						emitterToParticleShape.emitter = obj;
						emitterToParticleShape.particleShape = it.item();

						fnDagNode.setObject(obj);
						if(emitterToParticleShapeList.end() == 
						   std::find(emitterToParticleShapeList.begin(), emitterToParticleShapeList.end(), emitterToParticleShape))
						{
							emitterToParticleShapeList.push_back(emitterToParticleShape);
						};
					}
					break;
					default: break;
				}
			}
		}
		it.next();
		m_attributeExporter.CloseGroup();
	}
	m_attributeExporter.CloseGroup();

	m_attributeExporter.StartNewGroup("Fields");
	for(MObjects::const_iterator i = mFields.begin();
		i != mFields.end(); ++i)
	{
		const MObject &obj = *i;
		switch(obj.apiType()) 
		{
			case MFn::kGravity:
				ExtractGravityFieldData(obj);
				break;
			case MFn::kRadial:
				ExtractRadialFieldData(obj);
				break;
			case MFn::kAir:
			case MFn::kDrag:
			case MFn::kNewton:
			case MFn::kTurbulence:
			case MFn::kUniform:
			case MFn::kVortex:
			case MFn::kVolumeAxis:
				ExtractGeneralFieldData(obj);
			break;
		}
	}
	m_attributeExporter.CloseGroup();

	m_attributeExporter.StartNewGroup("Emitters");
	for(EmitterToParticleShapeList::const_iterator i = emitterToParticleShapeList.begin();
		i != emitterToParticleShapeList.end(); ++i)
	{
		const MObject &obj = (*i).emitter;
		switch(obj.apiType()) 
		{
			
			case MFn::kEmitter:
				ExtractGeneralEmmiterData(obj, (*i).particleShape);
			break;
			default: break;
		}
	}
	m_attributeExporter.CloseGroup();

}

 
MStatus initializePlugin( MObject obj ) 
{ 
    MFnPlugin plugin( obj, "Jonas Kaulakis", "1.0", "Any" ); 

	MStatus status =  plugin.registerFileTranslator(ParticleExporter::EXPORTER_NAME , 
						"", 
						ParticleExporter::creator); 

    return MS::kSuccess; 
} 

MStatus uninitializePlugin( MObject obj ) 
{ 
    MFnPlugin plugin( obj ); 

	MStatus status =  plugin.deregisterFileTranslator(ParticleExporter::EXPORTER_NAME); 
	if (!status) { 
		status.perror("deregisterFileTranslator"); 
		return status; 
	} 
	return status; 
} 
 




#include "AttributeExporter.h"

#include <maya/MStatus.h>
#include <maya/MPlug.h>

#include <maya/MFnDependencyNode.h>

#include <maya/MFnAttribute.h>
#include <maya/MFnEnumAttribute.h>
#include <maya/MFnNumericAttribute.h>
#include <maya/MFnUnitAttribute.h>


#include "ExpDataHandler.h"

#define REPORT_UNSUPORTED_DATA_TYPE_ERROR(type)		\
{													\
	cerr << "\nUnsuported numeric attribute type: "	\
		 << type << __FILE__						\
		 <<	" at line "	<< __LINE__ << endl;		\
}													\


#define REPORT_EXPORT_ERROR							\
{													\
	cerr << "\nError exporting data " << __FILE__	\
		 <<	" at line "	<< __LINE__ << endl;		\
}													\

namespace ParticleSample
{
	AttributeExporter::AttributeExporter()
	{
	}

	void AttributeExporter::StartNewGroup(const char *groupName)
	{
		m_dataHandler->StartNewGroup(groupName);
	}

	void AttributeExporter::CloseGroup()
	{
		m_dataHandler->CloseGroup();
	}


	MStatus AttributeExporter::Export(const char *attributeName)
	{
		MStatus status = MStatus::kFailure;
		MFnDependencyNode fnDependencyNode(m_mObject, &status);
		CHECK_MSTATUS_AND_RETURN_IT(status);
		MObject attribute = fnDependencyNode.attribute(attributeName, &status);
		CHECK_MSTATUS_AND_RETURN_IT(status);
		return Export(attribute);
	}

	MStatus AttributeExporter::Export(MObject attribute)
	{
		MStatus status = MStatus::kFailure;
		if(m_dataHandler)
		{
			MFnDependencyNode fnNode(m_mObject, &status);
			CHECK_MSTATUS_AND_RETURN_IT(status);
			MPlug plug = fnNode.findPlug(attribute, true, &status);
			CHECK_MSTATUS_AND_RETURN_IT(status);

			MFnAttribute fnAttribute(attribute, &status);
			CHECK_MSTATUS_AND_RETURN_IT(status);

			MFn::Type attributeType = attribute.apiType();

			switch(attributeType)
			{
			case MFn::kAttribute2Double:
			case MFn::kAttribute3Double:
			case MFn::kAttribute4Double:
			case MFn::kNumericAttribute:
				return GetNumericAttributeValue(attribute, plug);
			case MFn::kDoubleAngleAttribute:
				return GetUnitAttribute(attribute, plug);
			case MFn::kDoubleLinearAttribute:
				return GetUnitAttribute(attribute, plug);
			case MFn::kEnumAttribute:
				return GetEnumAttributeValue(attribute, plug);
			case MFn::kUnitAttribute:
				return GetUnitAttribute(attribute, plug);
			default:
				REPORT_UNSUPORTED_DATA_TYPE_ERROR(attributeType);
				break;
			}
			return status;
		}
		else
		{
			cerr << "\nData handler is not set. "__FILE__<<	" at line "	<< __LINE__ << endl;
			return status;
		}
	}

	MStatus AttributeExporter::GetEnumAttributeValue(MObject attribute, MPlug plug)
	{
		MStatus status = MStatus::kFailure;
		
		MFnEnumAttribute	fnEnumAttr(attribute, &status);
		CHECK_MSTATUS_AND_RETURN_IT(status);

		short index = plug.asShort(MDGContext::fsNormal, &status);
		CHECK_MSTATUS_AND_RETURN_IT(status);

		MString name = fnEnumAttr.name(&status);
		CHECK_MSTATUS_AND_RETURN_IT(status);

		MString fieldName = fnEnumAttr.fieldName(index, &status);
		CHECK_MSTATUS_AND_RETURN_IT(status);

		if(!m_dataHandler->ExportShort(index, name.asChar()))
		{
			REPORT_EXPORT_ERROR;
		}
		return status;
	}

	MStatus AttributeExporter::GetNumericAttributeValue(MObject attribute, MPlug plug)
	{
		MStatus status = MStatus::kFailure;

		MFnNumericAttribute	fnNumericAttr(attribute, &status);
		CHECK_MSTATUS_AND_RETURN_IT(status);

		MFnNumericData::Type numerinType = fnNumericAttr.unitType(&status);
		CHECK_MSTATUS_AND_RETURN_IT(status);

		MString name = fnNumericAttr.name(&status);
		CHECK_MSTATUS_AND_RETURN_IT(status);

		switch(numerinType)
		{
		case MFnNumericData::kInvalid:

		case MFnNumericData::kBoolean:	//Boolean 
			{
				bool value = plug.asBool(MDGContext::fsNormal, &status);
				CHECK_MSTATUS_AND_RETURN_IT(status);
				if(!m_dataHandler->ExportBool(value, name.asChar()))
				{
					REPORT_EXPORT_ERROR;
				}
				break;
			}
		case MFnNumericData::kByte:		//One byte  
		case MFnNumericData::kChar:		//One character  
		case MFnNumericData::kShort:	//One short  
		case MFnNumericData::k2Short:	//Two shorts
		case MFnNumericData::k3Short:	//Three shorts  
			REPORT_UNSUPORTED_DATA_TYPE_ERROR(numerinType);
		//case MFnNumericData::kLong:	//One long (actually int since "long" is not platform-consistent)  
		case MFnNumericData::kInt:		//One int  
			{
				int value = plug.asInt(MDGContext::fsNormal, &status);
				CHECK_MSTATUS_AND_RETURN_IT(status);
				if(!m_dataHandler->ExportInt(value, name.asChar()))
				{
					REPORT_EXPORT_ERROR
				}
			}
			break;
		case MFnNumericData::k2Int:		//Two ints  
		case MFnNumericData::k3Int:		//Three ints 

		case MFnNumericData::kFloat:	//One float  
		case MFnNumericData::k2Float:	//Two floats  
		case MFnNumericData::k3Float:	//Three floats  
			REPORT_UNSUPORTED_DATA_TYPE_ERROR(numerinType);
			break;
		case MFnNumericData::kDouble:	//One double 
			{
				double value = plug.asDouble(MDGContext::fsNormal, &status);
				CHECK_MSTATUS_AND_RETURN_IT(status);
				if(!m_dataHandler->ExportDouble(value, name.asChar()))
				{
					REPORT_EXPORT_ERROR
				}
				break;
			}
		case MFnNumericData::k2Double:	//Two doubles  
		case MFnNumericData::k3Double:	//Three doubles  
		case MFnNumericData::k4Double:	//Four doubles
			{				
				size_t childCount = plug.numChildren(&status);
				CHECK_MSTATUS_AND_RETURN_IT(status);

				double values[4];
				for(size_t i = 0; i < childCount; ++i)
				{					
					MPlug chilPlug = plug.child(i, &status);
					CHECK_MSTATUS_AND_RETURN_IT(status);
					values[i] = chilPlug.asDouble(MDGContext::fsNormal, &status);
					CHECK_MSTATUS_AND_RETURN_IT(status);
				}
				m_dataHandler->ExportDouble(&values[0], childCount, name.asChar());
			}
		case MFnNumericData::kAddr:		//An address    
			break;
		default:
			REPORT_UNSUPORTED_DATA_TYPE_ERROR(numerinType);
		}
		return status;
	}

	MStatus AttributeExporter::GetUnitAttribute(MObject attribute, MPlug plug)
	{
		MStatus status = MStatus::kFailure;

		MFnUnitAttribute fnUnitAttr(attribute, &status);
		CHECK_MSTATUS_AND_RETURN_IT(status);

		MFnUnitAttribute::Type numerinType = fnUnitAttr.unitType(&status);
		CHECK_MSTATUS_AND_RETURN_IT(status);

		MString name = fnUnitAttr.name(&status);
		CHECK_MSTATUS_AND_RETURN_IT(status);

		switch(numerinType)
		{
		case MFnUnitAttribute::kInvalid:
			REPORT_UNSUPORTED_DATA_TYPE_ERROR(numerinType);
			break;

		case MFnUnitAttribute::kAngle:
		case MFnUnitAttribute::kDistance:
			{
				double value = plug.asDouble(MDGContext::fsNormal, &status);
				CHECK_MSTATUS_AND_RETURN_IT(status);
				if(!m_dataHandler->ExportDouble(value, name.asChar()))
				{
					REPORT_EXPORT_ERROR;
				}
			}
			break;			
		case MFnUnitAttribute::kTime:
		default:
			REPORT_UNSUPORTED_DATA_TYPE_ERROR(numerinType);
		}
		return status;
	}
}
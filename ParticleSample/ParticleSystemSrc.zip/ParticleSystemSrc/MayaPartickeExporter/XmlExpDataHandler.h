#pragma once

#include "ExpDataHandler.h"

class TiXmlElement;

namespace ParticleSample
{
	// Concrete exporter, which exports data to XML file
	class XmlExpDataHandler: public ExpDataHandler
	{
	public:
		virtual void StartNewGroup(const char *groupName);
		virtual void CloseGroup();
		virtual bool ExportString(const  char *value, const char *attributeName);
		virtual bool ExportDouble(double value, const char *attributeName);
		virtual bool ExportDouble(double *values, size_t count, const char *attributeName);
		virtual bool ExportInt(int value, const char *attributeName);
		virtual bool ExportBool(bool value, const char *attributeName);
		virtual bool ExportShort(short value, const char *attributeName);
		void SetXmlElement(TiXmlElement *xmlElement);
	
	private:
		// Element into which exporter will export data
		TiXmlElement *m_currentXmlElement;
	};

	inline void XmlExpDataHandler::SetXmlElement(TiXmlElement *xmlElement)
	{
		m_currentXmlElement = xmlElement;
	}
}
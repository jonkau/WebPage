#pragma once

#include "d3d10.h"

#include "Includes.h"

namespace ParticleSample
{
	// Primitive geometry drawer with very simple shader
	class SimpleDrawer
	{
	public:
		SimpleDrawer(ID3D10Device *d3dDevice);
		~SimpleDrawer();
		void Draw(ID3D10Buffer *vertexBuffers, UINT primitiveCount, const Matrix4 &worldViewProj);
	private:

		HRESULT Init();
		void Release();

		ID3D10Device *m_d3dDevice;
		ID3D10Effect *m_effect;
		ID3D10EffectTechnique *m_technique;

		ID3D10InputLayout *m_vertexLayout;

		ID3D10EffectMatrixVariable *m_worldViewProj;		
	};
}
// included only for D3DXVECTOR3, D3DXVECTOR2, D3DXMATRIX and D3DXVECTOR4
#include <d3dx10.h>

typedef D3DXVECTOR2 Vector2;
typedef D3DXVECTOR3 Vector3;
typedef D3DXVECTOR4 Vector4;
typedef D3DXMATRIX  Matrix4;
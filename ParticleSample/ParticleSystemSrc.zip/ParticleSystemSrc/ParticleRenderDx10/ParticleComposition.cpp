#include "ParticleComposition.h"

#include "IParticleHolder.h"
#include "IEmitter.h"
#include "Fields/IField.h"
#include "Fields/FieldCollection.h"

namespace ParticleSample
{
	ParticleComposition::ParticleComposition()
	{
	}

	ParticleComposition::~ParticleComposition()
	{
		for(FieldCollectionsIterator i = m_fieldCollections.begin(); i != m_fieldCollections.end();
			++i)
		{
			delete (*i).second;
		}

		for(FieldIterator i = m_fields.begin(); i != m_fields.end();
			++i)
		{
			delete (*i).second;
		}

		for(EmitterIterator i = m_emitters.begin(); i != m_emitters.end();
			++i)
		{
			delete (*i).second;
		}
	}

	
	void ParticleComposition::Update(float deltaTime)
	{
		for(EmitterIterator i = m_emitters.begin(); i != m_emitters.end();
			++i)
		{
			(*i).second->Update(deltaTime);
		}

		for(FieldCollectionsIterator i = m_fieldCollections.begin(); i != m_fieldCollections.end();
			++i)
		{
			(*i).second->Update(deltaTime);
		}
	}

	void ParticleComposition::Render(const Matrix4 &worldViewProj)
	{
		for(FieldCollectionsIterator i = m_fieldCollections.begin(); i != m_fieldCollections.end();
			++i)
		{
			(*i).second->GetParticleHolder()->Render(worldViewProj);
		}
	}

	
	void ParticleComposition::AddField(const std::string &name, IField *field)
	{
		m_fields.insert(std::make_pair(name, field));
	}

	void ParticleComposition::AddParticleHolder(const std::string &name, IParticleHolder *particleHolder)
	{
		m_fieldCollections.insert(std::make_pair(name, new FieldCollection(particleHolder)));
	}

	void ParticleComposition::AddEmitter(const std::string &name, IEmitter *emitter)
	{
		m_emitters.insert(std::make_pair(name, emitter));
	}

	IParticleHolder* ParticleComposition::GetParticleHolder(const std::string &name)
	{
		FieldCollections::const_iterator fieldCollIter = m_fieldCollections.find(name);
		return (*fieldCollIter).second->GetParticleHolder();
	}

	void ParticleComposition::ConnectFieldToParticleHolder(const std::string &fieldName,
														   const std::string &particleHolderName)
	{
		//TODO: chech for errors
		Fields::const_iterator fieldIter = m_fields.find(fieldName);
		FieldCollections::const_iterator fieldCollIter = m_fieldCollections.find(particleHolderName);
		(*fieldCollIter).second->AddField((*fieldIter).second);

	}

	void ParticleComposition::DebugEvent()
	{
		for(FieldCollectionsIterator i = m_fieldCollections.begin(); i != m_fieldCollections.end();
			++i)
		{
			(*i).second->GetParticleHolder()->DebugEvent();
		}

	}
}
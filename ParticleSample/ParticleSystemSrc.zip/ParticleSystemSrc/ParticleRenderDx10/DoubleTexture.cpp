#include "DoubleTexture.h"

namespace ParticleSample
{
	DoubleTexture::DoubleTexture(ID3D10Device *d3dDevice, UINT width, UINT height)
		:m_texture0(d3dDevice, width, height), 
		 m_texture1(d3dDevice, width, height)
	{
		m_sourceTexture = &m_texture0;
		m_targetTexture = &m_texture1;

	}

	void DoubleTexture::Switch()
	{
		Texture *temp = m_sourceTexture;
		m_sourceTexture = m_targetTexture;
		m_targetTexture = temp;
	}
}

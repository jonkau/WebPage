#pragma once

#include <d3dx10.h>

namespace ParticleSample
{
	// Class for full screen rendering
	class FullQuad
	{
	public:
		FullQuad(ID3D10Device *d3dDevice);
		~FullQuad();
		// Render quad with specified technique
		void Render(ID3D10EffectTechnique *technique) const;
	private:
		HRESULT Init();
		void Release();

		// Directx stuff
		ID3D10Device *m_d3dDevice;
		ID3D10Buffer *m_quadVB;
	};
}

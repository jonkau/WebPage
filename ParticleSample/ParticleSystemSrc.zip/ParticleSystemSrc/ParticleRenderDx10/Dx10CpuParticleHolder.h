#pragma once 

#include "Includes.h"
#include "BaseParticleHolder.h"

namespace ParticleSample
{
	// Class is used to hold and render Directx10 Cpu based particles.
	// for particle update is used calculation on single Cpu core;
	// for particle render is used discard and no_overwrite method.
	class Dx10CpuParticleHolder: public BaseParticleHolder
	{
	public:
		// Represents single particle in memory
		struct ParticleVertex
		{
			//Vector3 position;
			Vector3 speed;
			float	lifespan;
		};

		Dx10CpuParticleHolder(const Data &data, ID3D10Device *d3dDevice);
		~Dx10CpuParticleHolder();
		
		// For comments on virtual methods see class IParticleHolder
		virtual void Update(float deltaTime);
		virtual void AddParticle(const Vector3 &position, const Vector3 &speed);
		virtual void ApplayField(const IField *field, float deltaTime);
		virtual void Render(const Matrix4 &worldViewProj);

		// Following methods are not virtual and are inlined,
		// because they are called many times per frame

		// Returns particle data at index
		const ParticleVertex& GetParticleData(UINT index) const;
		const Vector3& GetParticlePosition(UINT index) const;
		
		// Returns active particle count
		UINT GetParticleCount() const;

		// Add speed to specified particle,
		// particle's mass is assumed to be 1 kg
		void AddSpeed(const Vector3 &speed, UINT index);
	private:
		const static UINT MAX_BATCH_SIZE = 1024;
		const static UINT MAX_BUFFER_SIZE = 2048 * 8;

		HRESULT Init();
		void Release();
		
		// Buffer offset is used for rendering
		UINT m_currentBufferOffset;
		// Active particle count
		UINT m_particleCount;

		// Particle array to store particles
		ParticleVertex *m_vertices;
		
		Vector3 *m_positions;

		// Directx10 specific stuff
		ID3D10Device *m_d3dDevice;

		ID3D10InputLayout *m_particleVertexLayout;
		ID3D10Buffer *m_particleVB;

		ID3D10Effect *m_effect;
		ID3D10EffectTechnique *m_technique;
		ID3D10EffectMatrixVariable *m_worldViewProj;
	};

	inline const Dx10CpuParticleHolder::ParticleVertex& Dx10CpuParticleHolder::GetParticleData(UINT index) const
	{
		return m_vertices[index];
	}

	inline const Vector3& Dx10CpuParticleHolder::GetParticlePosition(UINT index) const
	{
		return m_positions[index];
	}

	inline UINT Dx10CpuParticleHolder::GetParticleCount() const
	{
		return m_particleCount;
	}

	inline void Dx10CpuParticleHolder::AddSpeed(const Vector3 &speed, UINT index)
	{
		m_vertices[index].speed += speed;
	}
}

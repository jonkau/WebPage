#include "PointEmitter.h"

#include <assert.h>

#include "Utils.h"
#include "IParticleHolder.h"
#include "Defines.h"

namespace ParticleSample
{

	PointEmitter::PointEmitter(IParticleHolder *particleHolder, const BaseEmitter::Data &data)
		:BaseEmitter(particleHolder, data), m_timeTillNextEmit(0.0f)
	{
		EmitRateUpdated();
	}

	void PointEmitter::Update(float deltaTime)
	{		
		const static Vector3 VEC3_UNIT_X(1, 0, 0);
		const static Vector3 VEC3_UNIT_Y(0, 1, 0);

		m_timeTillNextEmit += deltaTime;
		while(m_timeTillNextEmit >= m_emitPeriod) 
		{
			m_timeTillNextEmit -= m_emitPeriod; 
			float directionOffset =  randf(GetData().minDistance, GetData().maxDistace);
			float speed = GetData().speed - GetData().speedRandom / 2 + randf(GetData().speedRandom);
			
			Vector3 direction(1.0f, 0.0f, 0.0f);

			switch(GetData().type)
			{
			case Data::T_OMNI:
				{										
					Matrix4 mZRotation;
					D3DXMatrixRotationZ(&mZRotation, randf(2.0f * PI));

					Matrix4 mYRotation;
					D3DXMatrixRotationY(&mYRotation, randf(2.0f * PI));

					Matrix4 mRotation(mYRotation * mZRotation);

					//for test use mYRotation;
					D3DXVec3TransformNormal(&direction, &direction, /*&mYRotation*/&mRotation);
				}
			break;
			case Data::T_DIRECTIONAL:
				{
					Vector3 normal(1.0f, 0.0f, 0.0f);

					float angle = randf(0, PI * 2.0f);

					Matrix4 mXRotation;
					D3DXMatrixRotationX(&mXRotation, angle);

					Matrix4 mYRotation;
					D3DXMatrixRotationY(&mYRotation, randf(-GetData().spread, GetData().spread) * PI * 0.5f);


					Vector3 perpend;
					D3DXVec3Cross(&perpend, &GetData().direction, &VEC3_UNIT_X);

					float len = D3DXVec3Length(&perpend);
					if(len < 1e-06)
					{
						D3DXVec3Cross(&perpend, &direction, &VEC3_UNIT_Y);
						len = D3DXVec3Length(&perpend);
					}

					perpend /= len;
					Vector3 right;
					D3DXVec3Cross(&right, &perpend, &GetData().direction);

					Matrix4 mInitRotation(	GetData().direction.x, GetData().direction.y, GetData().direction.z, 0.0f,
											perpend.x, perpend.y, perpend.z, 0.0f,	
											right.x, right.y, right.z, 0.0f,									
											0.0f, 0.0f, 0.0f, 0.0f);

					Matrix4 mRotation(mYRotation * mXRotation * mInitRotation);



					D3DXVec3TransformNormal(&direction, &direction, &mRotation);
				}
			break;
			default:
				assert(false);				
				break;
			}

			GetParticleHolder()->AddParticle(GetData().position + direction * directionOffset, direction * speed);
		}
	}

	void PointEmitter::EmitRateUpdated()
	{
		m_emitPeriod = 1 / GetData().emitRate;
	}

}
#include "Camera.h"

namespace ParticleSample
{
	Camera::Camera(float aspectRatio, const Vector3& position, const Vector3 look)
		:m_isMatrixValid(false), m_position(position), 
		m_look(look), m_aspectRatio(aspectRatio)
	{
		GetViewProjectionMatrix();
	}

	const Matrix4& Camera::GetViewProjectionMatrix() const
	{
		RecalculateCamera();
		return m_cachedMatrix;
	}

	void Camera::SetPosition(const Vector3& position)
	{		
		m_position = position;
		m_isMatrixValid = false;
	}

	void Camera::SetLook(const Vector3& look)
	{
		m_look = look;
		D3DXVec3Normalize(&m_look, &m_look);
		m_isMatrixValid = false;
	}

	const Vector3& Camera::GetLook() const
	{
		return m_look;
	}

	const Vector3& Camera::GetRight() const
	{
		RecalculateCamera();
		return m_right;
	}

	const Vector3& Camera::GetUp() const
	{
		RecalculateCamera();
		return m_up;
	}

	void Camera::RecalculateCamera() const
	{
		if(!m_isMatrixValid)
		{
			Matrix4 view;
			Matrix4 projection;

			Vector3 up( 0.0f, 1.0f, 0.0f );

			memset(&view, 0, sizeof(view));

			D3DXVec3Cross(&m_right, &up, &m_look);
			D3DXVec3Normalize(&m_right, &m_right);
			D3DXVec3Cross(&m_up, &m_look, &m_right);
			D3DXVec3Normalize(&m_up, &m_up);

			view._11 = m_right.x;
			view._12 = m_up.x;
			view._13 = m_look.x;
			view._14 = 0.0f;

			view._21 = m_right.y;
			view._22 = m_up.y;
			view._23 = m_look.y;
			view._24 = 0.0f;

			view._31 = m_right.z;
			view._32 = m_up.z;
			view._33 = m_look.z;
			view._34 = 0.0f;

			view._41 = -D3DXVec3Dot(&m_position, &m_right);
			view._42 = -D3DXVec3Dot(&m_position, &m_up);
			view._43 = -D3DXVec3Dot(&m_position, &m_look);
			view._44 =  1.0f;

			// Initialize the projection matrix
			D3DXMatrixPerspectiveFovLH( &projection, (float)D3DX_PI * 0.5f, m_aspectRatio, 0.1f, 100.0f );
			m_cachedMatrix = view * projection;
			m_isMatrixValid = true;
		}
	}
}
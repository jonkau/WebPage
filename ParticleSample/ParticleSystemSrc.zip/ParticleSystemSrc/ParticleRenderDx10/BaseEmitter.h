#pragma once

#include "IEmitter.h"
#include "Includes.h"

namespace ParticleSample
{ 
	class IParticleHolder;

	// Base emitter class.
	// It is used to store basic emitter data.
	class BaseEmitter: public IEmitter
	{
	public:
		// All data are directly derived from Maya,
		// maybe this data is too specific for point emitter?
		struct Data
		{
			enum Type
			{
				T_DIRECTIONAL,
				T_OMNI
			};
			Type type;
			Vector3 position;
			float emitRate;
			// min and max distances from emitter position 
			// at which particles are born
			float minDistance;
			float maxDistace;
			// final speed is calculated  speed + random(-speedRandom/2, speedRandom/2) 
			float speed;
			float speedRandom;

			// is used only if type is T_DIRECTIONAL
			Vector3 direction;
			
			// Angle at which particles are distributed.
			// Angle is calculated spread * pi /2
			float spread;
		};

		BaseEmitter(IParticleHolder *particleHolder, const Data &data)
			:m_particleHolder(particleHolder), m_data(data)
		{
			// normalize for safety
			D3DXVec3Normalize(&m_data.direction, &m_data.direction);
		}

		const Data& GetData() const;
	protected:
		IParticleHolder* GetParticleHolder();
	private:
		IParticleHolder *m_particleHolder;
		Data m_data;
	};

	inline const BaseEmitter::Data& BaseEmitter::GetData() const
	{
		return m_data;
	}

	inline IParticleHolder* BaseEmitter::GetParticleHolder()
	{
		return m_particleHolder;
	}
}

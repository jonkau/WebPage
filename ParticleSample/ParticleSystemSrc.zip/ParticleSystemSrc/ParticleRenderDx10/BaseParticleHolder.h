#pragma once

#include "IParticleHolder.h"
#include "Utils.h"

namespace ParticleSample
{
	// Base particle holder class.
	// It is used to store base particle holder data
	class BaseParticleHolder: public IParticleHolder
	{
	public:
		// All data is directly derived from Maya
		struct Data
		{
			enum LifespanMode
			{
				LSM_CONST = 1,
				LSM_RANDOM = 2
			};
			UINT maxCount;
			// final life span is calculated lifespan + random(-lifespanRandom/2, lifespanRandom/2)
			float lifespanRandom;
			float lifespan;
			LifespanMode lifespanMode;

		};

		BaseParticleHolder(const Data &data)
			:m_data(data)
		{
		}
		const Data& GetData() const;
		const float GetLifespan() const;
	private:
		Data m_data;
	};

	inline const BaseParticleHolder::Data& BaseParticleHolder::GetData() const
	{
		return m_data;
	}

	inline const float BaseParticleHolder::GetLifespan() const
	{
		return GetData().lifespan + randf( -GetData().lifespanRandom / 2, GetData().lifespanRandom / 2);
	}
}

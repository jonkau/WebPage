#include "Texture.h"

#include "Defines.h"
#include "Exception.h"

namespace ParticleSample
{
	Texture::Texture(ID3D10Device *d3dDevice, UINT width, UINT height)
		:m_width(width), m_height(height),
		m_d3dTexture(NULL), m_d3dResourceView(NULL),
		m_d3dRenderTargetView(NULL)
	{
		HRESULT hr = Init(d3dDevice);
		if(!SUCCEEDED(hr))
		{
			Release();
			throw Exception(DXGetErrorDescription(hr), L"Texture::Texture");
		}
	}

	Texture::~Texture()
	{
		Release();
	}

	void Texture::SetShaderResource(ID3D10EffectShaderResourceVariable *shaderResourceView)
	{
		HRESULT hr;
		V(shaderResourceView->SetResource(m_d3dResourceView));
	}

	HRESULT Texture::Init(ID3D10Device *d3dDevice)
	{
		HRESULT hr;

		D3D10_TEXTURE2D_DESC textureDesc;
		memset(&textureDesc, 0, sizeof(textureDesc));
		textureDesc.ArraySize = 1;
		textureDesc.Height = m_height;
		textureDesc.Width = m_width;
		textureDesc.MipLevels = 1;
		textureDesc.SampleDesc.Count = 1;
		textureDesc.Usage = D3D10_USAGE_DEFAULT;
		textureDesc.BindFlags = D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET;
		textureDesc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;

		V_RETURN(d3dDevice->CreateTexture2D(&textureDesc, NULL, &m_d3dTexture));

		D3D10_RENDER_TARGET_VIEW_DESC renderTargetViewDesc;
		memset(&renderTargetViewDesc, 0, sizeof(renderTargetViewDesc));
		renderTargetViewDesc.Format = textureDesc.Format;
		renderTargetViewDesc.ViewDimension = D3D10_RTV_DIMENSION_TEXTURE2D;

		V_RETURN(d3dDevice->CreateRenderTargetView(m_d3dTexture, &renderTargetViewDesc, &m_d3dRenderTargetView)); 

		V_RETURN(d3dDevice->CreateShaderResourceView(m_d3dTexture, NULL, &m_d3dResourceView));

		return S_OK;
	}

	void Texture::Release()
	{
		SAFE_RELEASE(m_d3dTexture);
		SAFE_RELEASE(m_d3dResourceView);
		SAFE_RELEASE(m_d3dRenderTargetView);
	}

}
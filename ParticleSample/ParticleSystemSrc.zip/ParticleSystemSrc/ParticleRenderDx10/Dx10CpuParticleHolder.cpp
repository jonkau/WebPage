#include "Dx10CpuParticleHolder.h"

#include <algorithm>

#include "Fields/IField.h"
#include "Utils.h"
#include "Defines.h"

#include "Defines.h"
#include "Exception.h"

#include <DXErr.h>

namespace ParticleSample
{

	Dx10CpuParticleHolder::Dx10CpuParticleHolder(const Data &data, ID3D10Device *d3dDevice)
		:BaseParticleHolder(data),
		m_currentBufferOffset(0), m_particleCount(0), 
		m_vertices(new ParticleVertex[GetData().maxCount]),
		m_positions(new Vector3[GetData().maxCount]),
		m_d3dDevice(d3dDevice),
		m_particleVertexLayout(NULL), m_particleVB(NULL),
		m_effect(NULL), m_technique(NULL), m_worldViewProj(NULL)
	{
		HRESULT hr = Init();
		if(!SUCCEEDED(hr))
		{
			Release();
			throw Exception(DXGetErrorDescription(hr), L"Dx10CpuParticleHolder::Dx10CpuParticleHolder");
		}
	}

	Dx10CpuParticleHolder::~Dx10CpuParticleHolder()
	{
		Release();
	}

	void Dx10CpuParticleHolder::Update(float deltaTime)
	{	
		// update particle position		
		for(UINT i = 0; i < m_particleCount; ++i)
		{
			m_vertices[i].lifespan -= deltaTime;
			if(m_vertices[i].lifespan <= 0.0f)
			{
				--m_particleCount;
				m_vertices[i] = m_vertices[m_particleCount];
				m_positions[i] = m_positions[m_particleCount];
				--i;
			}
			else
			{
				// update particle position
				m_positions[i] += m_vertices[i].speed * deltaTime;
			}
		}
	}

	void Dx10CpuParticleHolder::AddParticle(const Vector3 &position, const Vector3 &speed)
	{
		if(m_particleCount < GetData().maxCount)
		{
			//m_vertices[m_particleCount].position = position;
			m_positions[m_particleCount] = position;
			m_vertices[m_particleCount].speed = speed;

			m_vertices[m_particleCount].lifespan = GetLifespan();
			++m_particleCount;
		}	
	}

	void Dx10CpuParticleHolder::ApplayField(const IField *field, float deltaTime)
	{
		field->ApplayField(this, deltaTime);
	}

	void Dx10CpuParticleHolder::Render(const Matrix4 &worldViewProj)
	{
		HRESULT hr = S_OK;

		// Set the input layout
		m_d3dDevice->IASetInputLayout( m_particleVertexLayout );

		V(m_worldViewProj->SetMatrix((float*)&worldViewProj));

		// Set vertex buffer
		UINT stride = sizeof( Vector3 );
		UINT offset = 0;
		m_d3dDevice->IASetVertexBuffers( 0, 1, &m_particleVB, &stride, &offset );

		// Set primitive topology
		m_d3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );

		UINT particlesRendered = 0;
		while(particlesRendered  != m_particleCount)
		{
			UINT renderBatchSize = std::min(m_particleCount - particlesRendered, MAX_BATCH_SIZE);
			if(m_currentBufferOffset + renderBatchSize > MAX_BUFFER_SIZE)
			{
				m_currentBufferOffset = 0;
			}
				    
			Vector3 *buffer;
			V(m_particleVB->Map(m_currentBufferOffset == 0?D3D10_MAP_WRITE_DISCARD:D3D10_MAP_WRITE_NO_OVERWRITE, 0, (void**)&buffer));

			memcpy(buffer[m_currentBufferOffset], m_positions[particlesRendered], sizeof(Vector3) * renderBatchSize);
			particlesRendered += renderBatchSize;

			m_particleVB->Unmap();

			D3D10_TECHNIQUE_DESC techDesc;
			m_technique->GetDesc( &techDesc );
			for( UINT p = 0; p < techDesc.Passes; ++p )
			{
				m_technique->GetPassByIndex( p )->Apply(0);
				m_d3dDevice->Draw( renderBatchSize, m_currentBufferOffset );
			}

			m_currentBufferOffset += renderBatchSize ;
		}
	}

	HRESULT Dx10CpuParticleHolder::Init()
	{
		HRESULT hr;	


	    // Create the effect
		DWORD dwShaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;
		#if defined( DEBUG ) || defined( _DEBUG )
		dwShaderFlags |= D3D10_SHADER_DEBUG;
		#endif

		V_RETURN(D3DX10CreateEffectFromFile(L"Shaders/CpuParticles.fx", NULL, NULL, "fx_4_0", dwShaderFlags, 0, 
									m_d3dDevice, NULL, NULL, &m_effect, NULL, NULL ));

		m_worldViewProj = m_effect->GetVariableByName("g_mWorldViewProj")->AsMatrix();
		m_technique = m_effect->GetTechniqueByName("Render");

		D3D10_PASS_DESC passDesc;
		V_RETURN(m_technique->GetPassByIndex(0)->GetDesc(&passDesc));

	    D3D10_INPUT_ELEMENT_DESC layout[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D10_INPUT_PER_VERTEX_DATA, 0 },  
		};

		UINT numElements = sizeof(layout)/sizeof(layout[0]);

		V_RETURN(m_d3dDevice->CreateInputLayout(layout, numElements, passDesc.pIAInputSignature, passDesc.IAInputSignatureSize, &m_particleVertexLayout));
		

		// Create vertex buffer
		D3D10_BUFFER_DESC bd;
		bd.Usage = D3D10_USAGE_DYNAMIC;
		bd.ByteWidth = sizeof(Vector3) * MAX_BUFFER_SIZE;
		bd.BindFlags = D3D10_BIND_VERTEX_BUFFER;
		bd.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
		bd.MiscFlags = 0;
		V_RETURN(m_d3dDevice->CreateBuffer(&bd, NULL, &m_particleVB));

		return S_OK;
	}

	void Dx10CpuParticleHolder::Release()
	{
		SAFE_RELEASE(m_particleVertexLayout);
		SAFE_RELEASE(m_particleVB);
		SAFE_RELEASE(m_effect);

		SAFE_DELETE_ARRAY(m_positions);
		SAFE_DELETE_ARRAY(m_vertices);
	}
};

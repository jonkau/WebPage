#pragma once

#include "d3d10.h"
#include "IParticleSystemFactory.h"

namespace ParticleSample
{
	// Specific factory class.
	// It is used to create Directx10 Cpu based particle objects
	class Dx10CpuParticleSystemFactory: public IParticleSystemFactory
	{
	public:
		Dx10CpuParticleSystemFactory(ID3D10Device *d3dDevice);
		virtual PointEmitter* CreatePointEmitter(const BaseEmitter::Data &data, IParticleHolder *particleHolder) const;
		virtual BaseParticleHolder* CreateParticleHolder(const BaseParticleHolder::Data &data) const;
	
	private:
		ID3D10Device *m_d3dDevice;
	};

}
#pragma once
#include "Includes.h"

namespace ParticleSample
{
	// Camera class for scene navigation
	class Camera
	{
	public:
		Camera(float aspectRatio, const Vector3& position, const Vector3 look);
		const Matrix4& GetViewProjectionMatrix() const;

		void SetPosition(const Vector3& position);
		void SetLook(const Vector3& look);
		const Vector3& GetPosition() const;
		// returns camera's vectors
		const Vector3& GetLook() const;
		const Vector3& GetRight() const; 
		const Vector3& GetUp() const; 
	private:
		void RecalculateCamera() const;
		mutable bool m_isMatrixValid;
		mutable Matrix4 m_cachedMatrix;

		Vector3 m_position;
		Vector3 m_look;
		mutable Vector3 m_right;
		mutable Vector3 m_up;
		float m_aspectRatio;
	};

	inline const Vector3& Camera::GetPosition() const
	{
		return m_position;
	}
}

#include "Dx10GpuParticleHolder.h"

#include <assert.h>
#include <algorithm>
#include <limits>

#include "Fields/IField.h"
#include "Utils.h"
#include "Defines.h"
#include "Exception.h"

namespace ParticleSample
{
	Dx10GpuParticleHolder::Dx10GpuParticleHolder(const Data &data, ID3D10Device *d3dDevice)
		:BaseParticleHolder(data),
		m_textureHeight(CeilPowerOfTwo((UINT) ceil(sqrtf((float)data.maxCount)))),
		m_textureWidth(m_textureHeight),
		m_maxParticleCount(m_textureHeight * m_textureHeight),

		m_currentBufferOffset(0),
		m_fullQuad(d3dDevice),

		m_currentNewParticleCount(0),
		m_freeParticleList(m_maxParticleCount),
		m_positionTextures(d3dDevice, m_textureWidth, m_textureWidth),
		m_speedTextures(d3dDevice, m_textureWidth, m_textureWidth),

		m_d3dDevice(d3dDevice),

		m_effect(NULL),
		m_technique(NULL),
		m_renderPixelTechnique(NULL),
		m_worldViewProj(NULL),
		m_particleVertexLayout(NULL),
		m_particleVB(NULL),

		m_renderPixelVertexLayout(NULL),

		m_textureShaderResource(NULL),

		m_dynamicParticleVB(NULL),

		m_gpuParticleUpdateEffect(NULL),
		m_particleUpdateTechnique(NULL),
		m_particleUpdateLayout(NULL),

		m_speedTextureVariable(NULL),
		m_positionTextureVariable(NULL),
		m_deltaTimeShaderResource(NULL),

		m_blendStateNoBlend(NULL)
	{
		HRESULT hr = Init();
		if(!SUCCEEDED(hr))
		{
			Release();
			throw Exception(DXGetErrorDescription(hr), L"Dx10GpuParticleHolder::Dx10GpuParticleHolder");
		}
		for(UINT i = 0; i < m_maxParticleCount; ++i)
		{
			m_freeParticleList.push_back(i);
		}
	}

	Dx10GpuParticleHolder::~Dx10GpuParticleHolder()
	{
		Release();
	}

	void Dx10GpuParticleHolder::Update(float deltaTime)
	{	
		HRESULT hr;
		m_activeParticleList.erase(std::remove_if(m_activeParticleList.begin(), m_activeParticleList.end(), RemoveOldParticles(deltaTime, m_freeParticleList)),
								   m_activeParticleList.end());

		V(m_deltaTimeShaderResource->SetFloat(deltaTime));

		ExecuteInContext(RenderFromPToMember(*this, &Dx10GpuParticleHolder::UpdateAndInsertNewParticles));
	}

	void Dx10GpuParticleHolder::AddParticle(const Vector3 &position, const Vector3 &speed)
	{
		if(m_currentNewParticleCount >= DYNAMIC_VERTEX_BUFFER_SIZE)
		{
			ExecuteInContext(RenderFromPToMember(*this, &Dx10GpuParticleHolder::InsertNewParticles));
		}

		if(m_freeParticleList.size() > 0)
		{
			UINT newIndex = m_freeParticleList.back();
			m_freeParticleList.pop_back();

			float lifespan = GetLifespan();
			
			m_newParticles[m_currentNewParticleCount].index.x = -1.0f + 2.0f / m_textureWidth * ((newIndex / m_textureHeight) + 0.5f);
			m_newParticles[m_currentNewParticleCount].index.y = -1.0f + 2.0f / m_textureHeight * ((newIndex % m_textureHeight) + 0.5f);			
			m_newParticles[m_currentNewParticleCount].speed.x = speed.x;
			m_newParticles[m_currentNewParticleCount].speed.y = speed.y;
			m_newParticles[m_currentNewParticleCount].speed.z = speed.z;
			m_newParticles[m_currentNewParticleCount].lifespan = lifespan;
			m_newParticles[m_currentNewParticleCount].position.x = position.x;
			m_newParticles[m_currentNewParticleCount].position.y = position.y;
			m_newParticles[m_currentNewParticleCount].position.z = position.z;
			m_newParticles[m_currentNewParticleCount].position.w = 1.0f;

			ActiveParticle activeParticle;
			activeParticle.index = newIndex;
			activeParticle.lifespan = lifespan;

			m_activeParticleList.push_back(activeParticle);


			++m_currentNewParticleCount;
		}
	}

	void Dx10GpuParticleHolder::ApplayField(const IField *field, float deltaTime)
	{
		ExecuteInContext(RenderField(*this, *field, deltaTime));
		m_speedTextures.Switch();		
	}

	void Dx10GpuParticleHolder::Render(const Matrix4 &worldViewProj)
	{
		HRESULT hr = S_OK;

		m_positionTextures.GetTarget()->SetShaderResource(m_textureShaderResource);
		// Set the input layout
		m_d3dDevice->IASetInputLayout( m_particleVertexLayout );

		m_worldViewProj->SetMatrix( (float*)&worldViewProj );

		UINT stride = sizeof( float );
		UINT offset = 0;

		m_d3dDevice->IASetVertexBuffers( 0, 1, &m_particleVB, &stride, &offset );
		m_d3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );


		RenderPasses(m_technique, m_maxParticleCount);

		ID3D10ShaderResourceView* pNULLViews[1] = {NULL};
		m_d3dDevice->VSSetShaderResources( 0, 1, pNULLViews );

		AdvanceStep();
	}

	void Dx10GpuParticleHolder::SetSpeedSourceShaderResource(ID3D10EffectShaderResourceVariable *shaderResourceView)
	{
		m_speedTextures.GetSource()->SetShaderResource(shaderResourceView);
	}

	void Dx10GpuParticleHolder::SetPositionSourceShaderResource(ID3D10EffectShaderResourceVariable *shaderResourceView)
	{
		m_positionTextures.GetSource()->SetShaderResource(shaderResourceView);
	}

	HRESULT Dx10GpuParticleHolder::Init()
	{
		HRESULT hr;

		D3D10_BLEND_DESC blendState;
		ZeroMemory(&blendState, sizeof(D3D10_BLEND_DESC));
		blendState.RenderTargetWriteMask[0] = D3D10_COLOR_WRITE_ENABLE_ALL;
		blendState.RenderTargetWriteMask[1] = D3D10_COLOR_WRITE_ENABLE_ALL;
		m_d3dDevice->CreateBlendState(&blendState, &m_blendStateNoBlend);


		float infinityColor[4] = { std::numeric_limits<float>::max(),
								   std::numeric_limits<float>::max(), 
								   std::numeric_limits<float>::max(),
								   std::numeric_limits<float>::max() };

		m_d3dDevice->ClearRenderTargetView(m_positionTextures.GetSource()->GetRenderTarget(), infinityColor);
		m_d3dDevice->ClearRenderTargetView(m_positionTextures.GetTarget()->GetRenderTarget(), infinityColor);

		m_d3dDevice->ClearRenderTargetView(m_speedTextures.GetSource()->GetRenderTarget(), infinityColor);
		m_d3dDevice->ClearRenderTargetView(m_speedTextures.GetTarget()->GetRenderTarget(), infinityColor);

	    // Create the effect
		DWORD dwShaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;
		#if defined( DEBUG ) || defined( _DEBUG )
		dwShaderFlags |= D3D10_SHADER_DEBUG;
		#endif

		V_RETURN(D3DX10CreateEffectFromFile(L"Shaders/GpuParticles.fx", NULL, NULL, "fx_4_0", dwShaderFlags, 0, 
									 m_d3dDevice, NULL, NULL, &m_effect, NULL, NULL));
		
		V_RETURN(D3DX10CreateEffectFromFile(L"Shaders/GpuParticleUpdate.fx", NULL, NULL, "fx_4_0", dwShaderFlags, 0, 
									 m_d3dDevice, NULL, NULL, &m_gpuParticleUpdateEffect, NULL, NULL));

		m_worldViewProj = m_effect->GetVariableByName( "g_mWorldViewProj" )->AsMatrix();
		m_textureShaderResource = m_effect->GetVariableByName( "g_texture" )->AsShaderResource();		

		m_technique =				m_effect->GetTechniqueByName( "Render" );
		m_renderPixelTechnique =	m_effect->GetTechniqueByName( "RenderPixel" );

		D3D10_PASS_DESC passDesc;

		V_RETURN(m_technique->GetPassByIndex(0)->GetDesc(&passDesc));

	    const D3D10_INPUT_ELEMENT_DESC particleLayout[] =
		{
			{ "POSITION",	0, DXGI_FORMAT_R32_FLOAT, 0, 0,	D3D10_INPUT_PER_VERTEX_DATA, 0 },		
		};

	    V_RETURN(m_d3dDevice->CreateInputLayout(particleLayout, sizeof( particleLayout ) / sizeof( particleLayout[0] ),
												passDesc.pIAInputSignature,
												passDesc.IAInputSignatureSize, &m_particleVertexLayout));
	
		V_RETURN(m_renderPixelTechnique->GetPassByIndex(0)->GetDesc(&passDesc));
		
	    const D3D10_INPUT_ELEMENT_DESC renderPixelLayout[] =
		{
			{ "ARRAY_POSITION",	0, DXGI_FORMAT_R32G32_FLOAT, 0, 0,	D3D10_INPUT_PER_VERTEX_DATA, 0 },
			{ "SPEED",	0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 8,	D3D10_INPUT_PER_VERTEX_DATA, 0 },
			{ "POSITION",	0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 24,	D3D10_INPUT_PER_VERTEX_DATA, 0 }
		};

	    V_RETURN(m_d3dDevice->CreateInputLayout(renderPixelLayout, sizeof( renderPixelLayout ) / sizeof( renderPixelLayout[0] ),
												passDesc.pIAInputSignature,
												passDesc.IAInputSignatureSize, &m_renderPixelVertexLayout));

		m_particleUpdateTechnique = m_gpuParticleUpdateEffect->GetTechniqueByName( "RenderUpdateParticles" );
		
		V_RETURN(m_particleUpdateTechnique->GetPassByIndex(0)->GetDesc(&passDesc));

		m_speedTextureVariable = m_gpuParticleUpdateEffect->GetVariableByName( "g_speedTexture" )->AsShaderResource();
		m_positionTextureVariable = m_gpuParticleUpdateEffect->GetVariableByName( "g_positionTexture" )->AsShaderResource();
		m_deltaTimeShaderResource =	m_gpuParticleUpdateEffect->GetVariableByName( "g_deltaTime" )->AsScalar();

		const D3D10_INPUT_ELEMENT_DESC updatepParticleLayout[] =
		{
			{ "POSITION",	0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0,	D3D10_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD",	0, DXGI_FORMAT_R32G32_FLOAT, 0, 12,	D3D10_INPUT_PER_VERTEX_DATA, 0 }
		};

	    V_RETURN(m_d3dDevice->CreateInputLayout(updatepParticleLayout, sizeof( updatepParticleLayout ) / sizeof( updatepParticleLayout[0] ),
												passDesc.pIAInputSignature,
												passDesc.IAInputSignatureSize, &m_particleUpdateLayout));
		
		// Create vertex buffers
		D3D10_BUFFER_DESC bd;

		bd.Usage = D3D10_USAGE_IMMUTABLE;
		bd.ByteWidth = sizeof(float) * m_maxParticleCount;
		bd.BindFlags = D3D10_BIND_VERTEX_BUFFER;
		bd.CPUAccessFlags = 0;
		bd.MiscFlags = 0;

		float *intiVectorData = new float[m_maxParticleCount];
		for(UINT i = 0; i < m_maxParticleCount; ++i)
		{
			intiVectorData[i] = (float)i;
		}

		D3D10_SUBRESOURCE_DATA initData;
	    initData.pSysMem = intiVectorData;
		initData.SysMemPitch = 0;
		initData.SysMemSlicePitch = 0;

		V_RETURN(m_d3dDevice->CreateBuffer(&bd, &initData, &m_particleVB));

		delete[] intiVectorData;

		// create buffer for rendering new particles
		bd.Usage = D3D10_USAGE_DYNAMIC;
		bd.ByteWidth = sizeof(NewParticle) * DYNAMIC_VERTEX_BUFFER_SIZE;
		bd.BindFlags = D3D10_BIND_VERTEX_BUFFER;
		bd.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
		bd.MiscFlags = 0;

		V_RETURN(m_d3dDevice->CreateBuffer(&bd, NULL, &m_dynamicParticleVB));

		return S_OK;
	}

	void Dx10GpuParticleHolder::Release()
	{
		SAFE_RELEASE(m_effect);

		SAFE_RELEASE(m_particleVertexLayout);
		SAFE_RELEASE(m_particleVB)

		SAFE_RELEASE(m_renderPixelVertexLayout);
		
		SAFE_RELEASE(m_dynamicParticleVB)

		SAFE_RELEASE(m_gpuParticleUpdateEffect);
		SAFE_RELEASE(m_particleUpdateLayout);

		SAFE_RELEASE(m_blendStateNoBlend)
	}

	void Dx10GpuParticleHolder::InsertNewParticles()
	{
		SetResources();
		SetRenderTargets();
						
		if(m_currentNewParticleCount > 0)
		{

			HRESULT hr = S_OK;
			UINT stride = sizeof( NewParticle );
			UINT offset = 0;

			m_d3dDevice->IASetInputLayout( m_renderPixelVertexLayout );
			m_d3dDevice->IASetVertexBuffers( 0, 1, &m_dynamicParticleVB, &stride, &offset );
			m_d3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );

			UINT particlesRendered = 0;
			while(particlesRendered  != m_currentNewParticleCount)
			{
				UINT renderBatchSize = std::min(m_currentNewParticleCount - particlesRendered, DYNAMIC_BUFFER_BATCH_SIZE);
				if(m_currentBufferOffset + renderBatchSize > DYNAMIC_VERTEX_BUFFER_SIZE)
				{
					m_currentBufferOffset = 0;
				}
					    
				NewParticle *buffer;
				V(m_dynamicParticleVB->Map(m_currentBufferOffset == 0?D3D10_MAP_WRITE_DISCARD:D3D10_MAP_WRITE_NO_OVERWRITE, 0, (void**)&buffer));

				memcpy(&buffer[m_currentBufferOffset], &m_newParticles[particlesRendered], sizeof(NewParticle) * renderBatchSize);
				particlesRendered += renderBatchSize;

				m_dynamicParticleVB->Unmap();

				D3D10_TECHNIQUE_DESC techDesc;
				m_renderPixelTechnique->GetDesc( &techDesc );
				for( UINT p = 0; p < techDesc.Passes; ++p )
				{
					m_renderPixelTechnique->GetPassByIndex(p)->Apply(0);
					m_d3dDevice->Draw(renderBatchSize, m_currentBufferOffset);
				}

				m_currentBufferOffset += renderBatchSize ;
			}
		}

		ClearResources();

		m_currentNewParticleCount = 0;
	}

	void Dx10GpuParticleHolder::UpdateParticles()
	{
		SetResources();
		SetRenderTargets();
						
		m_d3dDevice->IASetInputLayout( m_particleUpdateLayout );
		m_fullQuad.Render(m_particleUpdateTechnique);
		ClearResources();
	}


	void Dx10GpuParticleHolder::RenderPasses(ID3D10EffectTechnique *technique, UINT primitiveCount)
	{
		D3D10_TECHNIQUE_DESC techDesc;
		technique->GetDesc( &techDesc );
		for( UINT p = 0; p < techDesc.Passes; ++p )
		{
			technique->GetPassByIndex( p )->Apply(0);			
			m_d3dDevice->Draw(primitiveCount, 0);
		}
	}

	void Dx10GpuParticleHolder::DebugEvent()
	{	
	}

	void Dx10GpuParticleHolder::AdvanceStep()
	{
		m_positionTextures.Switch();
		m_speedTextures.Switch();
	}

	void Dx10GpuParticleHolder::ExecuteInContext(RenderableInContext &renderableInContext)
	{
		ID3D10BlendState *oldBlendState;
		float oldBlendFactor[4];
		UINT oldSampleMask;

		m_d3dDevice->OMGetBlendState(&oldBlendState, oldBlendFactor, &oldSampleMask);

		const static UINT RENDER_TARGET_TO_RESTORE = 2;
		// save render tergets and depth stencil views
		ID3D10RenderTargetView *oldRTView[RENDER_TARGET_TO_RESTORE];
	    ID3D10DepthStencilView *oldDSView[RENDER_TARGET_TO_RESTORE];
		memset(oldRTView, 0, sizeof(oldRTView));
		memset(oldDSView, 0, sizeof(oldDSView));
		m_d3dDevice->OMGetRenderTargets(RENDER_TARGET_TO_RESTORE, &oldRTView[0], &oldDSView[0]);

		// save view port
		UINT countOfViewPorts = 1;
		D3D10_VIEWPORT oldViewPortList;
		m_d3dDevice->RSGetViewports(&countOfViewPorts, &oldViewPortList);

		float  blendFactor[] = {1.0f, 1.0f, 1.0f, 1.0f};
		m_d3dDevice->OMSetBlendState(m_blendStateNoBlend, blendFactor, -1);

		D3D10_VIEWPORT vp;
		vp.Width = m_textureWidth;
		vp.Height = m_textureHeight;
		vp.MinDepth = 0.0f;
		vp.MaxDepth = 1.0f;
		vp.TopLeftX = 0;
		vp.TopLeftY = 0;
		m_d3dDevice->RSSetViewports(1, &vp);

		renderableInContext.Render();

		// restore and release
		m_d3dDevice->OMSetBlendState(oldBlendState, oldBlendFactor, oldSampleMask);
		if(oldBlendState) oldBlendState->Release();

		m_d3dDevice->RSSetViewports(countOfViewPorts, &oldViewPortList);

		m_d3dDevice->OMSetRenderTargets(RENDER_TARGET_TO_RESTORE, &oldRTView[0], oldDSView[0]);
		for( UINT i = 0; i < RENDER_TARGET_TO_RESTORE; ++i)
		{
			if(oldRTView[i])
			{
				oldRTView[i]->Release();
			}

			if(oldDSView[i])
			{
				oldDSView[i]->Release();
			}
		}
	}

	void Dx10GpuParticleHolder::UpdateAndInsertNewParticles()
	{
		UpdateParticles();
		InsertNewParticles();
	}	

	void Dx10GpuParticleHolder::SetRenderTargets()
	{
		ID3D10RenderTargetView *renderTargets[] = {m_speedTextures.GetTarget()->GetRenderTarget(), m_positionTextures.GetTarget()->GetRenderTarget()};
		m_d3dDevice->OMSetRenderTargets(sizeof(renderTargets) / sizeof(ID3D10RenderTargetView), renderTargets, NULL);
	}

	void Dx10GpuParticleHolder::SetResources()
	{
		m_speedTextures.GetSource()->SetShaderResource( m_speedTextureVariable );
		m_positionTextures.GetSource()->SetShaderResource( m_positionTextureVariable );

	}

	void Dx10GpuParticleHolder::ClearResources()
	{
		ID3D10ShaderResourceView* pNULLViews[2] = {NULL, NULL};
		m_d3dDevice->PSSetShaderResources( 0, 2, pNULLViews );
	}

	UINT Dx10GpuParticleHolder::CeilPowerOfTwo(UINT value) const
	{
		UINT shift = sizeof(UINT) * 8 - 1;
		UINT mask = (UINT)1 << shift;

		while(!(value & mask))
		{
			mask  = mask >> 1;
		}

		return mask << 1;
	}
};

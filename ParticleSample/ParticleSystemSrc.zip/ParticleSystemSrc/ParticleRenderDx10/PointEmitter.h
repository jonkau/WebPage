#pragma once 

#include "Includes.h"
#include "BaseEmitter.h"

namespace ParticleSample
{
	// Class represets emitter,
	// which can emit particles from one point in space
	class PointEmitter: public BaseEmitter
	{
	public:
		// Creates emitter with specified data, 
		// and particleHolder into which particles will be emitted.
		PointEmitter(IParticleHolder *particleHolder, const BaseEmitter::Data &data);
		
		// Updates emitter, which emits particles into particleHolder
		virtual void Update(float deltaTime);
	
	private:
		void EmitRateUpdated();
	
		float m_timeTillNextEmit;
		
		// Cached data calculated from emit rate
		float m_emitPeriod;
	};
}

#pragma once

#include <d3d10.h>

#include "Texture.h"


namespace ParticleSample
{
	// Helping class for double buffering
	class DoubleTexture
	{
	public:
		DoubleTexture(ID3D10Device *d3dDevice, UINT width, UINT height);
		// Switches source with destination
		void Switch();
		Texture* GetSource();
		Texture* GetTarget();
	private:
		Texture m_texture0;
		Texture m_texture1;
		Texture *m_sourceTexture;
		Texture *m_targetTexture;		
	};

	inline Texture* DoubleTexture::GetSource()
	{
		return m_sourceTexture;
	}

	inline Texture* DoubleTexture::GetTarget()
	{
		return m_targetTexture;
	}

}
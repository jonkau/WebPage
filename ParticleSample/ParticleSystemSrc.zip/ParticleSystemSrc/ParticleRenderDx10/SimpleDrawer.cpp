#include "SimpleDrawer.h"

#include "D3DX10Async.h"
#include "Defines.h"
#include "Exception.h"

namespace ParticleSample
{
	SimpleDrawer::SimpleDrawer(ID3D10Device *d3dDevice)
		:m_d3dDevice(d3dDevice), m_effect(NULL), m_vertexLayout(NULL)
	{
		HRESULT hr = Init();
		if(!SUCCEEDED(hr))
		{
			Release();
			throw Exception(DXGetErrorDescription(hr), L"SimpleDrawer::SimpleDrawer");
		}
	}

	SimpleDrawer::~SimpleDrawer()
	{
		Release();
	}

	void SimpleDrawer::Draw(ID3D10Buffer *vertexBuffers, UINT primitiveCount, const Matrix4 &worldViewProj)
	{
		UINT stride = sizeof(Vector3);
		UINT offset = 0;

		m_d3dDevice->IASetInputLayout(m_vertexLayout);

		m_d3dDevice->IASetVertexBuffers(0, 1, &vertexBuffers, &stride, &offset);
		m_d3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_LINELIST);

		m_worldViewProj->SetMatrix((float*)&worldViewProj);

		D3D10_TECHNIQUE_DESC techDesc;
		m_technique->GetDesc(&techDesc);
		for(UINT p = 0; p < techDesc.Passes; ++p)
		{
			m_technique->GetPassByIndex(p)->Apply(0);			
			m_d3dDevice->Draw(primitiveCount, 0);
		}
	}

	HRESULT SimpleDrawer::Init()
	{
		HRESULT hr = S_OK;	

	    // Create the effect
		DWORD dwShaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;
		#if defined( DEBUG ) || defined( _DEBUG )
		dwShaderFlags |= D3D10_SHADER_DEBUG;
		#endif

		V_RETURN(D3DX10CreateEffectFromFile(L"Shaders/SimpleDrawer.fx", NULL, NULL, "fx_4_0", dwShaderFlags, 0, 
											m_d3dDevice, NULL, NULL, &m_effect, NULL, NULL));
		
		m_worldViewProj = m_effect->GetVariableByName("g_mWorldViewProj")->AsMatrix();
		m_technique = m_effect->GetTechniqueByName("Render");


		D3D10_PASS_DESC passDesc;
		V_RETURN(m_technique->GetPassByIndex(0)->GetDesc(&passDesc));

	    D3D10_INPUT_ELEMENT_DESC layout[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D10_INPUT_PER_VERTEX_DATA, 0 },  
		};

		UINT numElements = sizeof(layout)/sizeof(layout[0]);

		V_RETURN(m_d3dDevice->CreateInputLayout(layout, numElements, passDesc.pIAInputSignature, passDesc.IAInputSignatureSize, &m_vertexLayout));
		return hr;
	}

	void SimpleDrawer::Release()
	{
		SAFE_RELEASE(m_effect);
		SAFE_RELEASE(m_vertexLayout);
	}
}

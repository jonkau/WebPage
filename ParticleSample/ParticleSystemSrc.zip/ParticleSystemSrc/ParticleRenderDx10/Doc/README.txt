Application supports GPU and CPU particle render.
To start particle simulation just drag and drop xml file which is exported from MAYA using particle exporter plugin.

CAMERA NAVIGATION:
 For rotation - hold left mouse button and move mouse in different directions.
 For moving - use dirrectional keys.


NOTE:
For now there are only basic functionality of two field types supported - gravity and radial.
Life time of particles can be only random or const.
Emitter supports omni or directional emmision.
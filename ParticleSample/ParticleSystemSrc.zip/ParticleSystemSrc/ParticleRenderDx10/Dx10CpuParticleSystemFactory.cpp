#include "Dx10CpuParticleSystemFactory.h"

#include "Dx10CpuParticleHolder.h"
#include "PointEmitter.h"

namespace ParticleSample
{
	Dx10CpuParticleSystemFactory::Dx10CpuParticleSystemFactory(ID3D10Device *d3dDevice)
		:m_d3dDevice(d3dDevice)
	{
	}
	PointEmitter* Dx10CpuParticleSystemFactory::CreatePointEmitter(const BaseEmitter::Data &data, IParticleHolder *particleHolder) const
	{
		// just create base 
		return new PointEmitter(particleHolder, data);
	}

	BaseParticleHolder* Dx10CpuParticleSystemFactory::CreateParticleHolder(const BaseParticleHolder::Data &data) const
	{
		Dx10CpuParticleHolder *dx10CpuParticleHolder = new Dx10CpuParticleHolder(data, m_d3dDevice);
		return dx10CpuParticleHolder;
	}
}
#pragma once

namespace ParticleSample
{
	class Dx10CpuParticleHolder;
	class Dx10GpuParticleHolder;
	// Field interface class.
	// Field has to know how to apply itself to all kinds of particles.
	class IField
	{
	public:
		virtual ~IField(){};
		
		// Transforms Dx10CpuParticleHolder type particles.
		virtual void ApplayField(Dx10CpuParticleHolder *dx10CpuParticleHolder, float deltaTime) const = 0;
		
		// Transforms Dx10GpuParticleHolder type particles.
		virtual void ApplayField(Dx10GpuParticleHolder *dx10GpuParticleHolder, float deltaTime) const = 0;
	};
}
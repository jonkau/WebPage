#pragma once

#include "BaseField.h"
#include "..\GpuAlgorithm.h"

namespace ParticleSample
{
	// Radial field pushes particles from the field position (center)
	class RadialField: public BaseField
	{
	public:
		RadialField(const BaseField::Data &data, ID3D10Device *d3dDevice);
		virtual void ApplayField(Dx10CpuParticleHolder *dx10CpuParticleHolder, float deltaTime) const;
		virtual void ApplayField(Dx10GpuParticleHolder *dx10GpuParticleHolder, float deltaTime) const;
	private:
		GpuAlgorithm m_gpuAlgorithm;	
		ID3D10EffectShaderResourceVariable *m_speedTexture;
		ID3D10EffectShaderResourceVariable *m_positionTexture;

		ID3D10EffectVectorVariable *m_effectFieldPosVariable;
		ID3D10EffectScalarVariable *m_effectDeltaTimeMulMagVariable;

		ID3D10Device *m_d3dDevice;
	};
}
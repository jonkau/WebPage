#pragma once

#include "IField.h"

#include "..\Includes.h"

namespace ParticleSample
{
	// BaseField class holds all fields common data.
	// In future it could do generic calculation on the particles.
	class BaseField: public IField
	{
	public:
		// For now it has only two members, 
		// but it can be expanded to support 
		// complex general field behaviour.
		struct Data
		{
			// Field position.
			// Not all fields forces are position depended.
			Vector3 position;
			// Describes general magnitude of field.
			float magnitude;
		};
		BaseField(const Data &data);
		const Vector3& GetPosition() const;
		const float GetMagnitude() const;
	
	private:
		Data m_data;
	};

	inline const Vector3& BaseField::GetPosition() const
	{
		return m_data.position;
	}

	inline const float BaseField::GetMagnitude() const
	{
		return m_data.magnitude;
	}
}
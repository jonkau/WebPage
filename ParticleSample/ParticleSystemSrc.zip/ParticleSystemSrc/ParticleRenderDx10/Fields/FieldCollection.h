#pragma once

#include <vector>

namespace ParticleSample
{
	class IField;
	class IParticleHolder;
	class IEmitter;

	// This class is designed 
	// to help applay field collection to one particle holder.
	class FieldCollection
	{
	public:
		FieldCollection(IParticleHolder *particleHolder);
		~FieldCollection();
		void Update(float deltaTime);
		void AddField(IField *field);
		IParticleHolder* GetParticleHolder();
	private:
		typedef std::vector<IField*> Fields;
		typedef Fields::iterator FieldIterator;

		IParticleHolder *m_particleHolder;
		Fields m_fields;
	};

	inline IParticleHolder* FieldCollection::GetParticleHolder()
	{
		return m_particleHolder;
	}
}
#include "FieldCollection.h"
#include "IField.h"
#include "../IParticleHolder.h"

namespace ParticleSample
{
	FieldCollection::FieldCollection(IParticleHolder *particleHolder)
		:m_particleHolder(particleHolder)
	{
	}

	FieldCollection::~FieldCollection()
	{
		delete m_particleHolder;
	}

	void FieldCollection::Update(float deltaTime)
	{
		for(Fields::const_iterator i = m_fields.begin(); i != m_fields.end();
			++i)
		{
			m_particleHolder->ApplayField(*i, deltaTime);
		}
		m_particleHolder->Update(deltaTime);
	}

	void FieldCollection::AddField(IField *field)
	{
		m_fields.push_back(field);
	}
}
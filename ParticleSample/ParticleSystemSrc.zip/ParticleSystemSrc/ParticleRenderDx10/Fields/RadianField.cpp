#include "RadialField.h"

#include "../Dx10CpuParticleHolder.h"
#include "../Dx10GpuParticleHolder.h"

#include "../Defines.h"

namespace ParticleSample
{
	RadialField::RadialField(const BaseField::Data &data, ID3D10Device *d3dDevice)
		:BaseField(data),
		m_gpuAlgorithm(d3dDevice, L"Shaders/Radial.fx"),
		m_d3dDevice(d3dDevice)
	{
		m_speedTexture = m_gpuAlgorithm.GetEffect()->GetVariableByName("g_speedTexture")->AsShaderResource();
		m_positionTexture = m_gpuAlgorithm.GetEffect()->GetVariableByName("g_positionTexture")->AsShaderResource();

		m_effectFieldPosVariable = m_gpuAlgorithm.GetEffect()->GetVariableByName("g_fieldPos")->AsVector();		
		m_effectDeltaTimeMulMagVariable = m_gpuAlgorithm.GetEffect()->GetVariableByName("g_deltaTimeMulMag")->AsScalar();
	}

	void RadialField::ApplayField(Dx10CpuParticleHolder *dx10CpuParticleHolder, float deltaTime) const
	{
		float deltaTimeMulMag = deltaTime * GetMagnitude();
		for(UINT i = 0; i < dx10CpuParticleHolder->GetParticleCount(); ++i)
		{
			Vector3 normDirection;
			Vector3 direction(dx10CpuParticleHolder->GetParticlePosition(i) - GetPosition());
			D3DXVec3Normalize(&normDirection, &direction);
			dx10CpuParticleHolder->AddSpeed(normDirection * deltaTimeMulMag , i);
		}
	}

	void RadialField::ApplayField(Dx10GpuParticleHolder *dx10GpuParticleHolder, float deltaTime) const
	{
		HRESULT hr;
		dx10GpuParticleHolder->SetSpeedSourceShaderResource(m_speedTexture);
		dx10GpuParticleHolder->SetPositionSourceShaderResource(m_positionTexture);

		Vector3 fieldPosition(GetPosition());
		V(m_effectFieldPosVariable->SetFloatVector(fieldPosition));
		V(m_effectDeltaTimeMulMagVariable->SetFloat(deltaTime * GetMagnitude()));

		m_gpuAlgorithm.Process();

		ID3D10ShaderResourceView* pNULLViews[2] = {NULL, NULL};
		m_d3dDevice->PSSetShaderResources(0, 2, pNULLViews);
	}
}

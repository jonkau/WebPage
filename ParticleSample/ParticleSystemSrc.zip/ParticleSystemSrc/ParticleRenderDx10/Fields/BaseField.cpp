#include "BaseField.h"

namespace ParticleSample
{
	BaseField::BaseField(const Data &data)
		:m_data(data)
	{
	}
}
#include "GravityField.h"
#include "../Dx10CpuParticleHolder.h"
#include "../Dx10GpuParticleHolder.h"
#include "../Defines.h"

namespace ParticleSample
{
	GravityField::GravityField(const Vector3 &gravityDirection, const BaseField::Data &data, ID3D10Device *d3dDevice)
		:BaseField(data),
		m_gravityDirection(gravityDirection),
		m_gravity(gravityDirection * data.magnitude),
		m_gpuAlgorithm(d3dDevice, L"Shaders/Gravity.fx"),
		m_d3dDevice(d3dDevice)
	{
		m_speedTexture = m_gpuAlgorithm.GetEffect()->GetVariableByName("g_speedTexture")->AsShaderResource();
		m_effectGravityVariable = m_gpuAlgorithm.GetEffect()->GetVariableByName("g_gravity")->AsVector();
	}

	void GravityField::ApplayField(Dx10CpuParticleHolder *dx10CpuParticleHolder, float deltaTime) const
	{
		Vector3 deltaTimeMulGrav = deltaTime * m_gravity;
		for(UINT i = 0; i < dx10CpuParticleHolder->GetParticleCount(); ++i)
		{
			dx10CpuParticleHolder->AddSpeed(deltaTimeMulGrav , i);
		}
	}

	void GravityField::ApplayField(Dx10GpuParticleHolder *dx10GpuParticleHolder, float deltaTime) const
	{
		HRESULT hr;
		V(m_effectGravityVariable->SetFloatVector(m_gravity * deltaTime));
		dx10GpuParticleHolder->SetSpeedSourceShaderResource(m_speedTexture);
		m_gpuAlgorithm.Process();
		ID3D10ShaderResourceView* pNULLViews[1] = {NULL};
		m_d3dDevice->PSSetShaderResources(0, 1, pNULLViews);
	}
}
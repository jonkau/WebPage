#pragma once

#include <d3d10.h>

#include "..\Includes.h"
#include "BaseField.h"
#include "..\GpuAlgorithm.h"

namespace ParticleSample
{
	// GravityField class adds gravity to particles.
	class GravityField: public BaseField
	{
	public:
		GravityField(const Vector3 &gravityDirection, const BaseField::Data &data, ID3D10Device *d3dDevice);
		virtual void ApplayField(Dx10CpuParticleHolder *dx10CpuParticleHolder, float deltaTime) const;
		virtual void ApplayField(Dx10GpuParticleHolder *dx10GpuParticleHolder, float deltaTime) const;
	private:
		// Gravity direction assigned in constructor
		Vector3 m_gravityDirection;
	
		// Cached gravity direction, multiplied by magnitude 
		Vector3 m_gravity;

		GpuAlgorithm m_gpuAlgorithm;	
		ID3D10EffectShaderResourceVariable *m_speedTexture;
		ID3D10EffectVectorVariable *m_effectGravityVariable;

		ID3D10Device *m_d3dDevice;
	};
}
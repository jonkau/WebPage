#pragma once

#include "Includes.h"

namespace ParticleSample
{
	class IField;
	
	// Interface for particle holder
	class IParticleHolder
	{
	public:
		virtual ~IParticleHolder(){};
		
		// Updates particle position according to applied fields
		// and current particle state
		virtual void Update(float deltaTime) = 0;
		
		// Adds new particle with specified parameters
		virtual void AddParticle(const Vector3 &position, const Vector3 &speed) = 0;
		
		// Applies field to particles collection
		virtual void ApplayField(const IField *field, float deltaTime) = 0;
		
		// Renders particles with specified transformation matrix
		virtual void Render(const Matrix4 &worldViewProj) = 0;

		virtual void DebugEvent(){};
	};
}
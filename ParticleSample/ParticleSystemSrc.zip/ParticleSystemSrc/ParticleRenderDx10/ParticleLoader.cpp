#pragma once

#include "ParticleLoader.h"

#include "../TinyXML/tinyxml.h"
#include "ParticleComposition.h"

#include "Fields/GravityField.h"
#include "Fields/RadialField.h"

#include "BaseEmitter.h"
#include "BaseParticleHolder.h"

#include "IParticleSystemFactory.h"

namespace ParticleSample
{

	const float ParticleLoader::MAYA_CONVERT_VALUE = 5.0f;

	static bool GetVector(const TiXmlElement *element, const char *attributeName, Vector3 &value)
	{
		const char* attribute = element->Attribute(attributeName);
		if(!attribute)
		{
			return NULL;
		}
		if (3 == sscanf_s(attribute, "%f;%f;%f", &value.x, &value.y, &value.z))
		{
			// change coordinate system
			value.x = -value.x;
			return true;
		}
		else
		{
			return false;
		}
		// return (3 == sscanf_s(attribute, "%f;%f;%f", &value.x, &value.y, &value.z));
	}

	static bool GetFloat(const TiXmlElement *element, const char *attributeName, float &value)
	{
		double doubleValue;
		if(element->Attribute(attributeName, &doubleValue))
		{
			value = (float) doubleValue;
			return true;
		}
		else
		{
			return false;
		}
	}

	static bool GetChar(const TiXmlElement *element, const char *attributeName, const char *&value)
	{
		if(value = element->Attribute(attributeName))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	static bool GetInt(const TiXmlElement *element, const char *attributeName, int &value)
	{
		return NULL != element->Attribute(attributeName, &value);
	}

	static bool LoadBaseParticleData(const TiXmlElement *elBaseField, BaseField::Data &data)
	{
		return ( GetVector(elBaseField, "translate", data.position) &&
				 GetFloat(elBaseField, "magnitude", data.magnitude)  );		
	}

	ParticleLoader::ParticleLoader(IParticleSystemFactory *particleSystemFactory, ID3D10Device *d3dDevice)
		:m_particleSystemFactory(particleSystemFactory), m_d3dDevice(d3dDevice)
	{

	}

	ParticleComposition* ParticleLoader::Load(const char* filePath)
	{
		TiXmlDocument xmlDocument(filePath);
		xmlDocument.LoadFile();

		const TiXmlElement *rootElement = xmlDocument.RootElement();
		if(rootElement)
		{
			ParticleComposition* particleComposition = new ParticleComposition();

			for(const TiXmlElement *elFields = rootElement->FirstChildElement("Fields");
				elFields != NULL; elFields = elFields->NextSiblingElement())
			{
				for(const TiXmlElement *elField = elFields->FirstChildElement();
					elField != NULL; elField = elField->NextSiblingElement())
				{
					if(strcmp(elField->Value(), "Gravity") == 0)
					{
						const TiXmlElement *elBaseField= elField->FirstChildElement("Field");

						const char *fieldName;
						Vector3 direction;

						BaseField::Data data;

						if(	elBaseField &&						   
							GetVector(elField, "direction", direction) &&
							GetChar(elBaseField, "name", fieldName) && 
							LoadBaseParticleData(elBaseField, data))
						{
							IField *field = new GravityField(direction, data, m_d3dDevice);
							particleComposition->AddField(fieldName, field);
						}
						
					}
					else if(strcmp(elField->Value(), "Radial") == 0)
					{
						const TiXmlElement *elBaseField= elField->FirstChildElement("Field");
						const char *fieldName;
						Vector3 direction;

						BaseField::Data data;

						if(	elBaseField &&						   							
							GetChar(elBaseField, "name", fieldName) && 
							LoadBaseParticleData(elBaseField, data))
						{
							data.magnitude *= MAYA_CONVERT_VALUE;
							IField *field = new RadialField(data, m_d3dDevice);
							particleComposition->AddField(fieldName, field);
						}
					}
				}
			}

			
			for(const TiXmlElement *elShapes = rootElement->FirstChildElement("ParticleShapes");
				elShapes != NULL; elShapes = elShapes->NextSiblingElement())
			{
				for(const TiXmlElement *element = elShapes->FirstChildElement("ParticleShape");
					element != NULL; element = element->NextSiblingElement())
				{
					BaseParticleHolder::Data data;
					int maxCount;
					const char *particleShapeName;

					if(GetFloat(element, "lifespanRandom", data.lifespanRandom) &&
					   GetFloat(element, "lifespan", data.lifespan) && 
					   GetInt(element, "maxCount", maxCount) &&
					   GetInt(element, "lifespanMode", (int&)data.lifespanMode) &&
					   GetChar(element, "name", particleShapeName))
					{
						assert(data.lifespanMode == BaseParticleHolder::Data::LSM_CONST || data.lifespanMode == BaseParticleHolder::Data::LSM_RANDOM);
						if(maxCount == -1)
						{
							//set default count
							maxCount = 10000;
						}
						data.maxCount = (UINT)maxCount;

						particleComposition->AddParticleHolder(particleShapeName, m_particleSystemFactory->CreateParticleHolder(data));

						for(const TiXmlElement *elField = element->FirstChildElement("Field");
						elField != NULL; elField = elField->NextSiblingElement())
						{
							const char *fieldName;
							if(GetChar(elField, "name", fieldName))
							{
								particleComposition->ConnectFieldToParticleHolder(fieldName, particleShapeName); 
							}
						}						
					}
				}
			}

			for(const TiXmlElement *elEmitters = rootElement->FirstChildElement("Emitters");
				elEmitters != NULL; elEmitters = elEmitters->NextSiblingElement())
			{
				for(const TiXmlElement *element = elEmitters->FirstChildElement("Emitter");
					element != NULL; element = element->NextSiblingElement())
				{
					BaseEmitter::Data data;

					const char* particleShapeName;
					const char* emitterName;

					if(	GetVector(element, "direction", data.direction) &&
						GetVector(element, "translate", data.position) &&
						GetFloat(element, "maxDistance", data.maxDistace) &&
						GetFloat(element, "minDistance", data.minDistance) &&
						GetFloat(element, "speed", data.speed) &&
						GetFloat(element, "speedRandom", data.speedRandom) && 
						GetFloat(element, "spread", data.spread) &&
						GetFloat(element, "rate", data.emitRate) && 
						GetChar(element, "particleShape", particleShapeName) &&
						GetChar(element, "name", emitterName) &&
						GetInt(element, "emitterType", (int&)data.type) )
					{					
						particleComposition->AddEmitter(emitterName, m_particleSystemFactory->CreatePointEmitter(data, particleComposition->GetParticleHolder(particleShapeName)));
					}
					else
					{
						//TODO report error
					}
				}
			}

			return particleComposition;
		}
		else
		{
			// root node does not exists
			return NULL;
		}
	};
}

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ParticleDx10.rc
//
#define IDI_ICON1                       101
#define IDI_PARTICLEDX10                101
#define IDD_SIMULATION_SELET_DIALOG     103
#define IDD_SIMULATION_SELECT_DIALOG    103
#define IDC_CPU                         1002
#define IDC_GPU                         1003
#define IDSIMULATIONGROUP               1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

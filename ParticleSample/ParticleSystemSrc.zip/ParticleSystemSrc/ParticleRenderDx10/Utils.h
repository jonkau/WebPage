#pragma once

#include "stdlib.h"
#include "Includes.h"

// Helper functions

namespace ParticleSample
{
	// Generates float random between min and max value
	inline float randf(float min, float max)
	{
		return min + (max - min)/RAND_MAX * rand();
	}

	// Generates random between 0 and max value
	inline float randf(float max)
	{
		return max / RAND_MAX * rand();
	}
}

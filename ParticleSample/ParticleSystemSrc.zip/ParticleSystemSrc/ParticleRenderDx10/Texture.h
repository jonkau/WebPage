#pragma once

#include <d3dx10.h>

namespace ParticleSample
{
	// Helper class simplifies texture resource usage as render target or source texture.
	// Always creates new texture.
	class Texture
	{
	public:
		Texture(ID3D10Device *d3dDevice, UINT width, UINT height);
		~Texture();
		UINT GetWidth() const;
		UINT Getheight() const;
		// Get texture as render target
		ID3D10RenderTargetView* GetRenderTarget();
		// Assign texture as source texture
		void SetShaderResource(ID3D10EffectShaderResourceVariable *shaderResourceView);
	private:

		HRESULT Init(ID3D10Device *d3dDevice);
		void Release();

		UINT m_width;
		UINT m_height;

		// Directx stuff
		ID3D10Texture2D *m_d3dTexture;
		ID3D10ShaderResourceView *m_d3dResourceView;
		ID3D10RenderTargetView *m_d3dRenderTargetView;

	};

	inline UINT Texture::GetWidth() const
	{
		return m_width;
	}

	inline UINT Texture::Getheight() const
	{
		return m_height;
	}

	inline ID3D10RenderTargetView* Texture::GetRenderTarget()
	{
		return m_d3dRenderTargetView;
	}
}
#pragma once
#include "PointEmitter.h"
#include "BaseParticleHolder.h"

namespace ParticleSample
{
	// Abstract particle system factory interface.
	// It is used to create particle system objects
	class IParticleSystemFactory
	{
	public:
		virtual ~IParticleSystemFactory(){};
		virtual PointEmitter* CreatePointEmitter(const BaseEmitter::Data &data, IParticleHolder *particleHolder) const = 0;
		virtual BaseParticleHolder* CreateParticleHolder(const BaseParticleHolder::Data &data) const = 0;
	};
}
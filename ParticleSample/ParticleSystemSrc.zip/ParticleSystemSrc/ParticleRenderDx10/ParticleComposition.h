#pragma once

#include <vector>
#include <map>
#include <string>

#include "Includes.h"

namespace ParticleSample
{
	class IParticleHolder;
	class IField;
	class IEmitter;
	class FieldCollection;

	// Class for representing Maya scene.
	// Typicaly it is created with ParticleLoader class
	class ParticleComposition
	{
	public:
		ParticleComposition();
		~ParticleComposition();

		// Updates all internal objects
		void Update(float deltaTime);

		// Renders all particle objects
		void Render(const Matrix4 &worldViewProj);

		// Adds field to the composition with specified name
		void AddField(const std::string &name, IField *field);
		
		// Adds particle holder to the composition with specified name
		void AddParticleHolder(const std::string &name, IParticleHolder *particleHolder);
		
		// Adds emitter to the composition with specified  name 
		void AddEmitter(const std::string &name, IEmitter *emitter);

		// Returns particle holder with specified name
		// TODO: consider not exposing internal members
		IParticleHolder* GetParticleHolder(const std::string &name);

		// Connects field to particleHolder by specifing their names.
		// After this field will be applied on every frame to the selected particle holder
		void ConnectFieldToParticleHolder(const std::string &fieldName, const std::string &particleHolderName);

		void DebugEvent();
	private:
		typedef std::map<std::string, IField*> Fields;
		typedef Fields::iterator FieldIterator;

		typedef std::map<std::string, FieldCollection*> FieldCollections;
		typedef FieldCollections::iterator FieldCollectionsIterator;

		typedef std::map<std::string, IEmitter*> Emitters;
		typedef Emitters::iterator EmitterIterator;

		Fields m_fields;
		FieldCollections m_fieldCollections;
		Emitters m_emitters;
	};
}

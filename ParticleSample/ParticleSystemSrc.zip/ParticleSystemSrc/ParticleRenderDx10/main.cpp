#include <windows.h>
#include <d3d10.h>
#include <d3dx10.h>
#include <D3DX10Core.h>

#include <stdio.h>

#include <assert.h>

#include <vector>

#include "resource.h"
#include "Dx10CpuParticleHolder.h"
#include "PointEmitter.h"
#include "Utils.h"
#include "Camera.h"

#include "Fields/GravityField.h"
#include "Fields/RadialField.h"

#include "Fields/FieldCollection.h"
#include "ParticleComposition.h"
#include "ParticleLoader.h"

#include "Dx10CpuParticleSystemFactory.h"
#include "Dx10GpuParticleSystemFactory.h"

#include "SimpleDrawer.h"

#include "Defines.h"

#include "Exception.h"

#ifdef _DEBUG
	#define _CRTDBG_MAP_ALLOC
	#include <crtdbg.h>
#endif

// Global Variables
HINSTANCE               g_hInst = NULL;  
HWND                    g_hWnd = NULL;
D3D10_DRIVER_TYPE       g_driverType = D3D10_DRIVER_TYPE_NULL;
ID3D10Device*           g_pd3dDevice = NULL;
IDXGISwapChain*         g_pSwapChain = NULL;
ID3D10RenderTargetView* g_pRenderTargetView = NULL;
ID3D10DepthStencilView* g_pDepthStencilView = NULL;
ID3D10Texture2D*		g_depthStencilBuffer = NULL;
ID3DX10Font*			g_pFont;

const float				g_fpsRefreshInMs = 100.0f;

const static UINT GRID_ROW_COUNT = 31;
const static UINT GRID_COLUMN_COUNT = 31;
const static float GRID_SPAN = 0.5f;

const static UINT GRID_VERTEX_COUNT = GRID_ROW_COUNT * 2 + GRID_COLUMN_COUNT * 2;


ID3D10Buffer *m_gridVB;

DWORD g_lastTickCountFps;
DWORD g_lastTickCount;
LARGE_INTEGER g_lastPerfCounter;
UINT g_frameCount;

// input handling
enum INPUTS
{
	I_UP,
	I_DOWN,
	I_RIGHT,
	I_LEFT
};

enum SimulationType
{
	ST_CPU,
	ST_GPU,
	ST_COUNT,
	ST_NONE,
};

int g_inputState = 0;

// mouse move
bool m_mousieLDown = false;
POINT g_currentMousePos;
POINT g_lastMousePos;

float g_xAngle = 0.0f;
float g_yAngle = 0.0f;

int g_xDiff = 0;
int g_yDiff = 0;

Matrix4 g_world;
const static Vector3 g_initLookDir(0.0f, 0.0f, -1.0f);
const static float CAMERA_ROTATION_SPEED = 0.001f;
const static float CAMERA_MOVE_SPEED = 10.0f;

typedef std::vector<ParticleSample::ParticleComposition*> ParticleCompositionList;
typedef std::vector<ParticleSample::ParticleComposition*>::iterator ParticleCompositionIterator;
ParticleCompositionList g_loadedCompositionList;
ParticleSample::ParticleLoader *g_particleLoader							= NULL;
ParticleSample::Camera *g_camera											= NULL;
ParticleSample::SimpleDrawer *g_simpleDrawer								= NULL;

ParticleSample::IParticleSystemFactory *g_particleSystemFactorys[ST_COUNT] = {NULL, NULL};


// Forward declarations
HRESULT             InitWindow( HINSTANCE hInstance, int nCmdShow );
HRESULT             InitDevice();
void                CleanupDevice();

LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR /*LRESULT */CALLBACK	AboutDlgProc(HWND, UINT, WPARAM, LPARAM);

void                Render();
void				Update(float deltaTime);
void				UpdateCamera(float deltaTime);
void				CameraAnglesChanged();
void				Run();
void				LoadFile(const char* fileName);
void				LoadFilesFromParams(LPWSTR lpCmdLine);


//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//--------------------------------------------------------------------------------------
int WINAPI wWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow )
{
	 //_crtBreakAlloc = 463;

    if( FAILED(InitWindow(hInstance, nCmdShow)) )
        return 0;

	try
	{
		HRESULT hr = InitDevice();
		if( FAILED(hr) )
		{
			MessageBox(g_hWnd, DXGetErrorDescription(hr), L"Error iniciating device.", MB_ICONERROR);
			CleanupDevice();	
			return 0;
		}
	}
	catch(const ParticleSample::Exception &ex)
	{
		wchar_t buffer[256];
		swprintf_s(buffer, L"Error \"%s\" in \"%s\".", ex.GetError(), ex.GetSource());

		MessageBox(g_hWnd, buffer, L"Error loading resource", MB_ICONERROR);
		return 0;
	}

	g_particleSystemFactorys[ST_CPU] = new ParticleSample::Dx10CpuParticleSystemFactory(g_pd3dDevice);
	g_particleSystemFactorys[ST_GPU]= new ParticleSample::Dx10GpuParticleSystemFactory(g_pd3dDevice);
	g_particleLoader = new ParticleSample::ParticleLoader(g_particleSystemFactorys[ST_CPU], g_pd3dDevice);

	LoadFilesFromParams(lpCmdLine);

	g_lastTickCountFps = GetTickCount();
	g_lastTickCount = GetTickCount();
	QueryPerformanceCounter(&g_lastPerfCounter);
	g_frameCount = 0;

	

	// Main message loop
	MSG msg = {0};
	while( WM_QUIT != msg.message )
	{
		if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
		else
		{
			Run(); 
		}
	}

	for(ParticleCompositionIterator i = g_loadedCompositionList.begin();
		i != g_loadedCompositionList.end();
		++i)
	{
		delete (*i);
	}

	for(UINT i = 0; i < ST_COUNT; ++i)
	{
		delete g_particleSystemFactorys[i];
	}

	delete g_particleLoader;
	delete g_camera;
	delete g_simpleDrawer;

    CleanupDevice();

	//_CrtDumpMemoryLeaks();
    return 0;
}


// Register class and create window
HRESULT InitWindow( HINSTANCE hInstance, int nCmdShow )
{
    // Register class
    WNDCLASSEX wcex;
    wcex.cbSize = sizeof(WNDCLASSEX); 
    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, (LPCTSTR)IDI_PARTICLEDX10);
    wcex.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = NULL;
    wcex.lpszClassName  = L"ParticleSampleWindowClass";
    wcex.hIconSm        = LoadIcon(wcex.hInstance, (LPCTSTR)IDI_PARTICLEDX10);
    if( !RegisterClassEx(&wcex) )
        return E_FAIL;

    // Create window
    g_hInst = hInstance; 
    RECT rc = { 0, 0, 1024, 768};
    AdjustWindowRect( &rc, WS_OVERLAPPEDWINDOW, FALSE );
    g_hWnd = CreateWindowEx(WS_EX_ACCEPTFILES, L"ParticleSampleWindowClass", L"Particle sample", WS_OVERLAPPEDWINDOW,
                           CW_USEDEFAULT, CW_USEDEFAULT, rc.right - rc.left, rc.bottom - rc.top, NULL, NULL, hInstance, NULL);
    if( !g_hWnd )
        return E_FAIL;

    ShowWindow( g_hWnd, nCmdShow );
  
    return S_OK;
}


// Create Direct3D device and swap chain
HRESULT InitDevice()
{
    HRESULT hr = S_OK;	

	IDXGIFactory *pDXGIFactory(NULL);

	V_RETURN(CreateDXGIFactory(__uuidof(IDXGIFactory), (void**)&pDXGIFactory));

	// Search for a PerfHUD adapter and try to use it. 
    UINT nAdapter = 0;
    IDXGIAdapter* adapter = NULL;
    IDXGIAdapter* selectedAdapter = NULL;
    D3D10_DRIVER_TYPE driverType = D3D10_DRIVER_TYPE_HARDWARE;

	while (pDXGIFactory->EnumAdapters(nAdapter, &adapter) != DXGI_ERROR_NOT_FOUND)
    {
      if (adapter)
      {
        DXGI_ADAPTER_DESC adaptDesc;
        if (SUCCEEDED(adapter->GetDesc(&adaptDesc)))
        {
          const bool isPerfHUD = wcscmp(adaptDesc.Description, L"NVIDIA PerfHUD") == 0;

          // Select the first adapter in normal circumstances or the PerfHUD one if it exists.
          if(nAdapter == 0 || isPerfHUD)
            selectedAdapter = adapter;
          
          if(isPerfHUD)
            driverType = D3D10_DRIVER_TYPE_REFERENCE;

          ++nAdapter;
        }
      }
    }

	if(pDXGIFactory) pDXGIFactory->Release();
    
    RECT rc;
    GetClientRect( g_hWnd, &rc );
    UINT width = rc.right - rc.left;
    UINT height = rc.bottom - rc.top;

    UINT createDeviceFlags = 0;
#ifdef _DEBUG
    createDeviceFlags |= D3D10_CREATE_DEVICE_DEBUG;
#endif

    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory( &sd, sizeof(sd) );
    sd.BufferCount = 1;
    sd.BufferDesc.Width = width;
    sd.BufferDesc.Height = height;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = g_hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;

    V_RETURN(D3D10CreateDeviceAndSwapChain(selectedAdapter, driverType, NULL, createDeviceFlags, 
                                            D3D10_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice));

    ID3D10Texture2D *pBuffer;

    V_RETURN(g_pSwapChain->GetBuffer( 0, __uuidof( ID3D10Texture2D ), (LPVOID*)&pBuffer));

    hr = g_pd3dDevice->CreateRenderTargetView( pBuffer, NULL, &g_pRenderTargetView);    
	pBuffer->Release();
    V_RETURN(hr);

	// Create depth stencil texture
    D3D10_TEXTURE2D_DESC descDepth;
    descDepth.Width = width;
    descDepth.Height = height;
    descDepth.MipLevels = 1;
    descDepth.ArraySize = 1;
    descDepth.Format = DXGI_FORMAT_D32_FLOAT;
    descDepth.SampleDesc.Count = 1;
    descDepth.SampleDesc.Quality = 0;
    descDepth.Usage = D3D10_USAGE_DEFAULT;
    descDepth.BindFlags = D3D10_BIND_DEPTH_STENCIL;
    descDepth.CPUAccessFlags = 0;
    descDepth.MiscFlags = 0;
	
    V_RETURN(g_pd3dDevice->CreateTexture2D(&descDepth, NULL, &g_depthStencilBuffer));


    // Create the depth stencil view
    D3D10_DEPTH_STENCIL_VIEW_DESC descDSV;
    descDSV.Format = descDepth.Format;
    descDSV.ViewDimension = D3D10_DSV_DIMENSION_TEXTURE2D;
    descDSV.Texture2D.MipSlice = 0;
    V_RETURN(g_pd3dDevice->CreateDepthStencilView(g_depthStencilBuffer, &descDSV, &g_pDepthStencilView));


    g_pd3dDevice->OMSetRenderTargets( 1, &g_pRenderTargetView, g_pDepthStencilView );

    // Setup the viewport
    D3D10_VIEWPORT vp;
    vp.Width = width;
    vp.Height = height;
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    vp.TopLeftX = 0;
    vp.TopLeftY = 0;
    g_pd3dDevice->RSSetViewports( 1, &vp );

	V_RETURN(D3DX10CreateFont(g_pd3dDevice, 15, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, 
                               OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                               L"Arial", &g_pFont));
	
	D3DXMatrixIdentity( &g_world );

	Vector3 camPos(0.0f, 10.0f, 10.0f);

	g_camera = new ParticleSample::Camera(width/(FLOAT)height, camPos, g_initLookDir);
	g_xAngle = -PI * 0.25f;
	CameraAnglesChanged();

	g_simpleDrawer = new ParticleSample::SimpleDrawer(g_pd3dDevice);

	// Create vertex buffer for grid drawing
	Vector3 gridData[GRID_VERTEX_COUNT];
	
	float gridHeight = (GRID_ROW_COUNT - 1) * GRID_SPAN;	
	float gridWidth = (GRID_COLUMN_COUNT - 1) * GRID_SPAN;

	UINT index = 0;
	for(UINT i = 0; i < GRID_ROW_COUNT; ++i)
	{
		float x = -gridHeight * 0.5f + i * GRID_SPAN;
		float z = gridWidth * 0.5f;
		gridData[index].x = x;
		gridData[index].y = 0.0f;
		gridData[index].z = z;
		++index ;
		gridData[index].x = x;
		gridData[index].y = 0.0f;
		gridData[index].z = -z;
		++index ;
	}

	for(UINT i = 0; i < GRID_COLUMN_COUNT; ++i)
	{
		float x = gridHeight * 0.5f;
		float z = -gridWidth * 0.5f + i * GRID_SPAN;
		gridData[index].x = x;
		gridData[index].y = 0.0f;
		gridData[index].z = z;
		++index ;
		gridData[index].x = -x;
		gridData[index].y = 0.0f;
		gridData[index].z = z;
		++index ;
		
	}
	
	D3D10_SUBRESOURCE_DATA initData;
    initData.pSysMem = gridData;
	initData.SysMemPitch = 0;
	initData.SysMemSlicePitch = 0;

	D3D10_BUFFER_DESC bd;
	bd.Usage = D3D10_USAGE_IMMUTABLE;
	bd.ByteWidth = sizeof(Vector3) * GRID_VERTEX_COUNT ;
	bd.BindFlags = D3D10_BIND_VERTEX_BUFFER;
	bd.CPUAccessFlags = 0;
	bd.MiscFlags = 0;
	V_RETURN(g_pd3dDevice->CreateBuffer(&bd, &initData, &m_gridVB));
	

    return S_OK;
}


// Clean up the objects we've created
void CleanupDevice()
{
    if( g_pd3dDevice ) g_pd3dDevice->ClearState();

	SAFE_RELEASE(g_pFont);
	SAFE_RELEASE(g_pDepthStencilView);
	SAFE_RELEASE(g_depthStencilBuffer );
    SAFE_RELEASE(g_pRenderTargetView);
    SAFE_RELEASE(g_pSwapChain);
    SAFE_RELEASE(g_pd3dDevice);
}


// Called every time the application receives a message
LRESULT CALLBACK WndProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
    PAINTSTRUCT ps;
    HDC hdc;

    switch (message) 
    {
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            EndPaint(hWnd, &ps);
            break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

		case WM_KEYDOWN:
			switch( wParam )
			{
				case VK_SPACE:
					for(ParticleCompositionIterator i = g_loadedCompositionList.begin();
						i != g_loadedCompositionList.end();
						++i)
					{
						(*i)->DebugEvent();
					}

					break;
				case VK_UP:
					g_inputState |= 1<<I_UP;
					break;

				case VK_DOWN:
					g_inputState |= 1<<I_DOWN;
					break;

				case VK_RIGHT:
					g_inputState |= 1<<I_RIGHT;
					break;

				case VK_LEFT:
					g_inputState |= 1<<I_LEFT;
					break;
			}
			break;	
		case WM_KEYUP:
			switch( wParam )
			{
				case VK_UP:
					g_inputState &= ~(1<<I_UP);
					break;

				case VK_DOWN:
					g_inputState &= ~(1<<I_DOWN);
					break;

				case VK_RIGHT:
					g_inputState &= ~(1<<I_RIGHT);
					break;

				case VK_LEFT:
					g_inputState &= ~(1<<I_LEFT);
					break;
			}
			break;	
		case WM_LBUTTONDOWN:
			{				
				g_currentMousePos.x = LOWORD (lParam);
				g_currentMousePos.y = HIWORD (lParam);
				g_lastMousePos = g_currentMousePos;
				m_mousieLDown = true;
				SetCapture(hWnd);
			}
			break;

		case WM_LBUTTONUP:
			{
				m_mousieLDown = false;
				ReleaseCapture();
			}
			break;

		
		case WM_MOUSEMOVE:
			{
				if(m_mousieLDown)
				{
					g_currentMousePos.x = (short)LOWORD(lParam);
					g_currentMousePos.y = (short)HIWORD(lParam);
					
					g_xDiff = g_currentMousePos.x - g_lastMousePos.x;
					g_yDiff = g_currentMousePos.y - g_lastMousePos.y;

					g_lastMousePos = g_currentMousePos;
				}
			}
			break;
		case WM_DROPFILES:
			{

				wchar_t wFilePath[MAX_PATH];
				char filePath[MAX_PATH];
				size_t charsConverted;
				HDROP hDrop = (HDROP) wParam;
				UINT fileCount = DragQueryFile ( hDrop, -1, NULL, 0 );
				
				for (UINT i = 0; i < fileCount; ++i)
				{
					if ( DragQueryFile( hDrop, i, wFilePath, MAX_PATH ) > 0 )
					{
						wcstombs_s(&charsConverted, filePath, wFilePath, MAX_PATH);
						LoadFile(filePath);
					}
				}
				DragFinish ( hDrop );
			}
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }

    return 0;
}

INT_PTR /*LRESULT */CALLBACK AboutDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{	
	static SimulationType *result = NULL;
	switch (message)
    {
    case WM_INITDIALOG:
		CheckRadioButton(hDlg, IDC_CPU, IDC_GPU, IDC_CPU) ;
		result = (SimulationType*) lParam;
		return TRUE;          
	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case IDOK:
		case IDCANCEL:
			if(LOWORD (wParam) == IDCANCEL)
			{
				*result = ST_NONE;
			}
			else if(LOWORD (wParam) == IDOK)
			{
				if(IsDlgButtonChecked (hDlg, IDC_CPU))
				{
					*result = ST_CPU;
				}
				else if(IsDlgButtonChecked (hDlg, IDC_GPU))
				{
					*result = ST_GPU;
				}
			}
			EndDialog(hDlg, 0);
			return TRUE;
		}
		break;
     }
     return FALSE;
}


void Update(float deltaTime)
{
	for(ParticleCompositionIterator i = g_loadedCompositionList.begin();
		i != g_loadedCompositionList.end();
		++i)
	{
		(*i)->Update(deltaTime);
	}
	UpdateCamera(deltaTime);
}

void UpdateCamera(float deltaTime)
{
	if(g_inputState)
	{
		Vector3 camPos = g_camera->GetPosition();
		Vector3 posOffset(0, 0, 0);

		if(g_inputState & 1<<I_UP)
		{
			posOffset += g_camera->GetLook() * deltaTime;
		}

		if(g_inputState & 1<<I_DOWN)
		{
			posOffset -= g_camera->GetLook() * deltaTime;
		}

		if(g_inputState & 1<<I_RIGHT)
		{
			posOffset += g_camera->GetRight() * deltaTime;
		}
		
		if(g_inputState & 1<<I_LEFT)
		{
			posOffset -= g_camera->GetRight() * deltaTime;
		}

		g_camera->SetPosition(camPos + posOffset * CAMERA_MOVE_SPEED);
	}

	if(g_yDiff != 0 || g_xDiff != 0)
	{
		g_xAngle += -g_yDiff * CAMERA_ROTATION_SPEED;
		g_yAngle +=  g_xDiff * CAMERA_ROTATION_SPEED;

		g_xDiff = 0;
		g_yDiff = 0;

		CameraAnglesChanged();
	}
}

void CameraAnglesChanged()
{
	static const float CAMERA_MAX_X_ANGLE = 0.9f * PI * 0.5f;
	if(g_xAngle > CAMERA_MAX_X_ANGLE)
	{
		g_xAngle = CAMERA_MAX_X_ANGLE;
	} 
	else if(g_xAngle < -CAMERA_MAX_X_ANGLE)
	{
		g_xAngle = -CAMERA_MAX_X_ANGLE;
	}

	Matrix4 xRotation;
	Matrix4 yRotation;
	D3DXMatrixRotationX(&xRotation, g_xAngle);
	D3DXMatrixRotationY(&yRotation, g_yAngle);

	Vector3 lookDir;
	D3DXVec3TransformNormal(&lookDir, &g_initLookDir, &(xRotation * yRotation));
	g_camera->SetLook(lookDir);

}

const static UINT FPS_BUFFER_SIZE= 256;
char static g_fpsBuffer[FPS_BUFFER_SIZE] = "FPS:";

void Run()
{
	DWORD newTickCount = GetTickCount();
	++g_frameCount;
	if(newTickCount - g_lastTickCountFps >= g_fpsRefreshInMs )
	{
		float fps = g_frameCount * 1000.0f / (newTickCount - g_lastTickCountFps); 
		g_frameCount = 0;
		g_lastTickCountFps = newTickCount;
		sprintf_s(g_fpsBuffer, "FPS: %f, Key State: %x, x angle: %f, mouse x: %i y: %i", fps, g_inputState, g_xAngle, g_lastMousePos.x, g_lastMousePos.y);
	}

	LARGE_INTEGER  newPerfCounter;
	LARGE_INTEGER  perfFrequancy;
	QueryPerformanceCounter(&newPerfCounter);
	QueryPerformanceFrequency(&perfFrequancy);


	float deltaTime = (float)(newPerfCounter.QuadPart - g_lastPerfCounter.QuadPart)/perfFrequancy.QuadPart;

	Update(deltaTime);
	Render();

	g_lastTickCount = newTickCount;
	g_lastPerfCounter = newPerfCounter;
}

void Render()
{	    
    float ClearColor[4] = { 0.0f, 0.125f, 0.3f, 1.0f };
    g_pd3dDevice->ClearRenderTargetView( g_pRenderTargetView, ClearColor );	

	g_pd3dDevice->ClearDepthStencilView( g_pDepthStencilView, D3D10_CLEAR_DEPTH, 1.0f, 0 );

	// we fine with default stencil depth state
	g_pd3dDevice->OMSetDepthStencilState(NULL, 0);

	for(ParticleCompositionIterator i = g_loadedCompositionList.begin();
		i != g_loadedCompositionList.end();
		++i)
	{
		(*i)->Render(g_camera->GetViewProjectionMatrix());
	}

	g_simpleDrawer->Draw(m_gridVB, GRID_VERTEX_COUNT, g_camera->GetViewProjectionMatrix());

	RECT rect;
	rect.top = 20;
	rect.left = 0;
	rect.right = 600;
	rect.bottom = 40;

	g_pFont->DrawTextA(NULL, g_fpsBuffer, -1, &rect, DT_LEFT, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f));
    g_pSwapChain->Present( 0, 0 );
}

void LoadFile(const char* fileName)
{
	SimulationType	simulationType;
	DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_SIMULATION_SELECT_DIALOG), g_hWnd, AboutDlgProc, (LPARAM)&simulationType);	

	if(simulationType < ST_COUNT)
	{
		g_particleLoader->SetParticleFactory(g_particleSystemFactorys[simulationType]);
		try
		{
			ParticleSample::ParticleComposition* loadedComposition = g_particleLoader->Load(fileName);
			if(loadedComposition)
			{
				g_loadedCompositionList.push_back(loadedComposition);
			}
			else
			{
				char buffer[256];
				sprintf_s(buffer, "Failed to load file \"%s\".", fileName);
				MessageBoxA(g_hWnd, buffer, "Error loading resource", MB_ICONERROR);
			}
		}
		catch(const ParticleSample::Exception &ex)
		{
			wchar_t buffer[256];
			swprintf_s(buffer, L"Error \"%s\" in \"%s\".", ex.GetError(), ex.GetSource());

			MessageBox(g_hWnd, buffer, L"Error loading resource", MB_ICONERROR);
		}
	}

	// Update perf counter to avoid huge delta times
	QueryPerformanceCounter(&g_lastPerfCounter);
}

void LoadFilesFromParams(LPWSTR lpCmdLine)
{
	size_t len  = wcslen( lpCmdLine ) + 1;
	char* path = new char[len];
	size_t charsConverted;
	wcstombs_s(&charsConverted, path, len, lpCmdLine, len);
	char* start = path;
	char* end = NULL;
	char endSimbol = ' ';

	while( *start != 0 )
	{
		if(*start != ' '  && *start != '"' )
		{
			end = start;
			while( *end != endSimbol && *end != '"' && *end != 0 )
			{
				++end;
			}			

			char *nextStart;
			if(*end == 0)
			{
				nextStart = end;
			}
			else
			{
				nextStart = end + 1;
			}

			*end = 0;
			LoadFile(start);

			start = nextStart;
			endSimbol = ' ';
		}
		else
		{
			endSimbol = *start;
			++start;
		}
	}
	delete[] path;
}
#pragma once

namespace ParticleSample
{
	// Emitter interface class.
	// Is needed for the way to update itself.
	class IEmitter
	{
	public:
		virtual ~IEmitter(){};
		virtual void Update(float deltaTime) = 0;
	};
}
#include "Dx10GpuParticleSystemFactory.h"

#include "Dx10GpuParticleHolder.h"
#include "PointEmitter.h"

namespace ParticleSample
{
	Dx10GpuParticleSystemFactory::Dx10GpuParticleSystemFactory(ID3D10Device *d3dDevice)
		:m_d3dDevice(d3dDevice)
	{
	}
	PointEmitter* Dx10GpuParticleSystemFactory::CreatePointEmitter(const BaseEmitter::Data &data, IParticleHolder *particleHolder) const
	{
		// just create base 
		return new PointEmitter(particleHolder, data);
	}

	BaseParticleHolder* Dx10GpuParticleSystemFactory::CreateParticleHolder(const BaseParticleHolder::Data &data) const
	{
		Dx10GpuParticleHolder *dx10GpuParticleHolder = new Dx10GpuParticleHolder(data, m_d3dDevice);
		return dx10GpuParticleHolder;
	}
}
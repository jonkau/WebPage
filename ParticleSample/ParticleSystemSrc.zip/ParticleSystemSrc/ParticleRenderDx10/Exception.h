#pragma once 

namespace ParticleSample
{
	// Exception class 
	class Exception
	{
	public:
		Exception(const wchar_t* error, const wchar_t* source)
			:m_error(error), m_source(source)
		{
		}
		const wchar_t* GetError() const;
		const wchar_t* GetSource() const;
	private:
		// error description
		const wchar_t* m_error;
		// error source
		const wchar_t* m_source;
	};

	inline const wchar_t* Exception::GetError() const
	{
		return m_error;
	}

	inline const wchar_t* Exception::GetSource() const
	{
		return m_source;
	}
}
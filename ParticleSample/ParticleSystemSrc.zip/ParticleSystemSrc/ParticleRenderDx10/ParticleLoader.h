#pragma once

#include "Includes.h"

namespace ParticleSample
{
	class IParticleSystemFactory;
	class ParticleComposition;
	// Particle composition loading class.
	// Currently loader loads only from xml file,
	// but in future, by making this class as interface,
	// we can consider loading from other media as well
	class ParticleLoader
	{
	public:
		// ParticleLoader constructor accepts IParticleSystemFactory,
		// which it uses to instantiate particle objects
		ParticleLoader(IParticleSystemFactory *particleSystemFactory, ID3D10Device *d3dDevice);
		
		// Returns loaded particle composition
		ParticleComposition* Load(const char* filePath);

		void SetParticleFactory(IParticleSystemFactory *m_particleSystemFactory);
	private:
		// Magic number to convert magnitude from MAYA to render application,
		// number was determined experimentally ( not much documentation from MAYA )
		const static float MAYA_CONVERT_VALUE;
		IParticleSystemFactory *m_particleSystemFactory;
		ID3D10Device *m_d3dDevice;
	};

	inline void ParticleLoader::SetParticleFactory(IParticleSystemFactory *particleSystemFactory)
	{
		m_particleSystemFactory = particleSystemFactory;
	}
}
#pragma once 

#include "Includes.h"
#include "BaseParticleHolder.h"
#include "Fields/IField.h"
#include "DoubleTexture.h"

#include "FullQuad.h"

#include <vector>
#include <list>

namespace ParticleSample
{
	// Class is used to hold and render Directx10 Gpu based particles.
	class Dx10GpuParticleHolder: public BaseParticleHolder
	{
	public:
		// Represents single particle in memory
		struct ParticleVertex
		{
			Vector3 position;
			Vector3 speed;
			float	lifespan;
		};

		Dx10GpuParticleHolder(const Data &data, ID3D10Device *d3dDevice);
		~Dx10GpuParticleHolder();
		
		// For comments on virtual methods see class IParticleHolder
		virtual void Update(float deltaTime);
		virtual void AddParticle(const Vector3 &position, const Vector3 &speed);
		virtual void ApplayField(const IField *field, float deltaTime);
		virtual void Render(const Matrix4 &worldViewProj);

		void SetSpeedSourceShaderResource(ID3D10EffectShaderResourceVariable *shaderResourceView);
		void SetPositionSourceShaderResource(ID3D10EffectShaderResourceVariable *shaderResourceView);

		virtual void DebugEvent();
	private:
		const static UINT DYNAMIC_VERTEX_BUFFER_SIZE = 512;
		const static UINT DYNAMIC_BUFFER_BATCH_SIZE = 128;

		struct NewParticle
		{
			Vector2 index;
			Vector3 speed;
			float lifespan;
			Vector4 position;
		};

		struct ActiveParticle
		{
			float lifespan;
			UINT index;
		};

		typedef std::vector<ActiveParticle> ActiveParticleList;
		typedef ActiveParticleList::iterator ActiveParticleListIter;


		typedef std::vector<UINT> FreeParticleList;
		typedef ActiveParticleList::iterator FreeParticleListIter;

		struct RemoveOldParticles
		{	
			RemoveOldParticles(float deltaTime, FreeParticleList& freeParticleList)
				:m_deltaTime(deltaTime), m_freeParticleList(freeParticleList)
			{}
			float m_deltaTime;
			FreeParticleList& m_freeParticleList;

			bool operator() (ActiveParticle &activeParticle) const
			{
				activeParticle.lifespan -= m_deltaTime;
				if(activeParticle.lifespan <= 0)
				{
					m_freeParticleList.push_back(activeParticle.index);
					return true;
				}
				else
				{
					return false;
				}
			}
		};

		class RenderableInContext
		{
		public:
			virtual void Render() = 0;
		};

		class RenderFromPToMember: public RenderableInContext
		{
		public:
			typedef void (Dx10GpuParticleHolder::*PtrToRender)();
			RenderFromPToMember(Dx10GpuParticleHolder &particleHolder, PtrToRender renderMemFn)
				:m_particleHolder(particleHolder), m_renderMemFn(renderMemFn)
			{
			}
			virtual void Render()
			{
				(m_particleHolder.*m_renderMemFn)();
			}
		private:
			Dx10GpuParticleHolder &m_particleHolder;
			PtrToRender m_renderMemFn;
		};

		class RenderField: public RenderableInContext
		{
		public:
			RenderField(Dx10GpuParticleHolder &particleHolder, const IField &currentField, float deltaTime)
				:m_particleHolder(particleHolder), m_currentField(currentField), m_deltaTime(deltaTime)
			{
			}
			virtual void Render()
			{
				ID3D10RenderTargetView *renderTargets[] = {m_particleHolder.m_speedTextures.GetTarget()->GetRenderTarget()};
				m_particleHolder.m_d3dDevice->OMSetRenderTargets(sizeof(renderTargets) / sizeof(ID3D10RenderTargetView), renderTargets, NULL);

				m_currentField.ApplayField(&m_particleHolder, m_deltaTime);			
			}
		private:
			Dx10GpuParticleHolder &m_particleHolder;
			const IField &m_currentField;
			float m_deltaTime;
		};

		
		HRESULT Init();
		void Release();
		
		void InsertNewParticles();
		void UpdateParticles();
		void UpdateAndInsertNewParticles();

		void RenderPasses(ID3D10EffectTechnique *technique, UINT primitiveCount);

		void AdvanceStep();

		void ExecuteInContext(RenderableInContext &renderableInContext);

		void SetRenderTargets();

		void SetResources();
		void ClearResources();

		UINT Dx10GpuParticleHolder::CeilPowerOfTwo(UINT value) const;

		const UINT m_textureHeight;
		const UINT m_textureWidth;

		const UINT m_maxParticleCount;

		UINT m_currentBufferOffset;

		FullQuad m_fullQuad;

		NewParticle m_newParticles[DYNAMIC_VERTEX_BUFFER_SIZE];
		UINT m_currentNewParticleCount;


		ActiveParticleList m_activeParticleList;
		FreeParticleList m_freeParticleList;



		// Directx10 specific stuff
		ID3D10Device *m_d3dDevice;

		ID3D10Effect *m_effect;
		ID3D10EffectTechnique *m_technique;
		ID3D10EffectTechnique *m_renderPixelTechnique;

		ID3D10EffectMatrixVariable *m_worldViewProj;

		ID3D10InputLayout* m_particleVertexLayout;
		ID3D10Buffer *m_particleVB;

		ID3D10InputLayout* m_renderPixelVertexLayout;

		// buffers for saving particle states
		DoubleTexture m_positionTextures;
		DoubleTexture m_speedTextures;
		
		// position texture, which is used in rendering process
		ID3D10EffectShaderResourceVariable *m_textureShaderResource;

		// buffer for rendering newly created particles 
		// into state buffers
		ID3D10Buffer *m_dynamicParticleVB;

		ID3D10Effect *m_gpuParticleUpdateEffect;
		ID3D10EffectTechnique *m_particleUpdateTechnique;
		ID3D10InputLayout *m_particleUpdateLayout;

		ID3D10EffectShaderResourceVariable *m_speedTextureVariable;
		ID3D10EffectShaderResourceVariable *m_positionTextureVariable;
		ID3D10EffectScalarVariable *m_deltaTimeShaderResource;

		ID3D10BlendState *m_blendStateNoBlend;
	};
}

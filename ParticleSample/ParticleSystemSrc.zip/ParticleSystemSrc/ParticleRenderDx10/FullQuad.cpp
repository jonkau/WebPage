#include "FullQuad.h"

#include "Includes.h"
#include "Defines.h"
#include "Exception.h"

namespace ParticleSample
{
	struct QuadVertex 
	{
		Vector3 pos;
		Vector2 tex;
	};

	FullQuad::FullQuad(ID3D10Device *d3dDevice)
		:m_d3dDevice(d3dDevice), m_quadVB(NULL)
	{
		HRESULT hr = Init();
		if(!SUCCEEDED(hr))
		{
			Release();
			throw Exception(DXGetErrorDescription(hr), L"FullQuad::FullQuad");
		}
	}

	FullQuad::~FullQuad()
	{
		Release();
	}

	void FullQuad::Render(ID3D10EffectTechnique *technique) const
	{
		UINT stride = sizeof(QuadVertex);
		UINT offset = 0;

		m_d3dDevice->IASetVertexBuffers(0, 1, &m_quadVB, &stride, &offset);
		m_d3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);

		D3D10_TECHNIQUE_DESC techDesc;
		technique->GetDesc(&techDesc);
		for( UINT p = 0; p < techDesc.Passes; ++p )
		{
			technique->GetPassByIndex(p)->Apply(0);			
			m_d3dDevice->Draw(4, 0);
		}
	}

	HRESULT FullQuad::Init()
	{
		HRESULT hr;
		float x = 1.0f;
		float neg_x = -1.0f;
		float y = 1.0f;
		float neg_y = -1.0f;


		QuadVertex vertexes[] = 
		{				
			{Vector3( x,	neg_y,	1.0f),		Vector2(1, 1)},
			{Vector3( neg_x,	neg_y,	1.0f),	Vector2(0, 1)},
			{Vector3( x,	 y,	1.0f),			Vector2(1, 0)},
			{Vector3( neg_x,  y,	1.0f),		Vector2(0, 0)}
		};
		
		D3D10_BUFFER_DESC bd;
		bd.Usage = D3D10_USAGE_IMMUTABLE;
		bd.ByteWidth = sizeof(vertexes);
		bd.BindFlags = D3D10_BIND_VERTEX_BUFFER;
		bd.CPUAccessFlags = 0;
		bd.MiscFlags = 0;


		D3D10_SUBRESOURCE_DATA initData;
		initData.pSysMem = vertexes;
		initData.SysMemPitch = 0;
		initData.SysMemSlicePitch = 0;

		V_RETURN(m_d3dDevice->CreateBuffer(&bd, &initData, &m_quadVB));
		return S_OK;
	}

	void FullQuad::Release()
	{
		SAFE_RELEASE(m_quadVB);		
	}
}
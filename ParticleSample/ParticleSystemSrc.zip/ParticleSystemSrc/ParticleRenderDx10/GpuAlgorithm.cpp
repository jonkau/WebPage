#include "GpuAlgorithm.h"

#include <D3DX10Async.h>

#include "Defines.h"
#include "Exception.h"

namespace ParticleSample
{
	GpuAlgorithm::GpuAlgorithm(ID3D10Device *d3dDevice, const wchar_t *fileName)
		:m_fullQuad(d3dDevice), m_d3dDevice(d3dDevice), 
		m_effect(NULL), m_technique(NULL), m_vertexLayout(NULL)
	{
		HRESULT hr = Init(fileName);
		if(!SUCCEEDED(hr))
		{
			Release();
			throw Exception(DXGetErrorDescription(hr), L"GpuAlgorithm::GpuAlgorithm");
		}
	}

	GpuAlgorithm::~GpuAlgorithm()
	{
		Release();
	}

	void GpuAlgorithm::Process() const
	{
		m_d3dDevice->IASetInputLayout(m_vertexLayout);
		m_fullQuad.Render(m_technique);
	}

	HRESULT GpuAlgorithm::Init(const wchar_t *fileName)
	{
		HRESULT hr;

		DWORD dwShaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;
		#if defined( DEBUG ) || defined( _DEBUG )
		dwShaderFlags |= D3D10_SHADER_DEBUG;
		#endif

		V_RETURN(D3DX10CreateEffectFromFile(fileName, NULL, NULL, "fx_4_0", dwShaderFlags, 0,
											m_d3dDevice, NULL, NULL, &m_effect, NULL, NULL));

		m_technique = m_effect->GetTechniqueByName("Algorithm");

		D3D10_PASS_DESC passDesc;

		V_RETURN(m_technique->GetPassByIndex(0)->GetDesc(&passDesc));
		
	    const D3D10_INPUT_ELEMENT_DESC elementLayoutDesc[] =
		{
			{ "POSITION",	0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0,	D3D10_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD",	0, DXGI_FORMAT_R32G32_FLOAT, 0, 12,		D3D10_INPUT_PER_VERTEX_DATA, 0 }, 
		};
		
	   V_RETURN(m_d3dDevice->CreateInputLayout(elementLayoutDesc, sizeof(elementLayoutDesc) / sizeof(elementLayoutDesc[0]),
												passDesc.pIAInputSignature,
												passDesc.IAInputSignatureSize, &m_vertexLayout));
	   return S_OK;
	}

	void GpuAlgorithm::Release()
	{
		SAFE_RELEASE(m_vertexLayout);
		SAFE_RELEASE(m_effect);
	}
}
#pragma once

#include <d3d10.h>

#include "FullQuad.h"

namespace ParticleSample
{
	// Class helps to apply specified effect with appropriate vertex layout.
	// Designed to be used by gpu field implementation
	class GpuAlgorithm
	{
	public:
		GpuAlgorithm(ID3D10Device *d3dDevice, const wchar_t *fileName);
		~GpuAlgorithm();
		// Executes algorithm
		void Process() const;
		ID3D10Effect* GetEffect();
	private:
		HRESULT Init(const wchar_t *fileName);
		void Release();
		FullQuad m_fullQuad;

		// Directx stuff
		ID3D10Device *m_d3dDevice;

		ID3D10Effect *m_effect;
		ID3D10EffectTechnique *m_technique;

		ID3D10InputLayout* m_vertexLayout;
	};

	inline ID3D10Effect* GpuAlgorithm::GetEffect()
	{
		return m_effect;
	}
}